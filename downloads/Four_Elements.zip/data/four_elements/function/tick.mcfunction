# Keep triggers enabled
scoreboard players enable @a fe_menu
scoreboard players enable @a fe_get_fire
scoreboard players enable @a fe_get_ice
scoreboard players enable @a fe_get_lightning
scoreboard players enable @a fe_get_earth

# Handle triggers
execute as @a run function four_elements:trigger_handler

# Decrement cooldowns
scoreboard players remove @a[scores={fe_cd_fire=1..}] fe_cd_fire 1
scoreboard players remove @a[scores={fe_cd_ice=1..}] fe_cd_ice 1
scoreboard players remove @a[scores={fe_cd_lightning=1..}] fe_cd_lightning 1
scoreboard players remove @a[scores={fe_cd_earth=1..}] fe_cd_earth 1

# Detect right click with elemental items
execute as @a[scores={fe_use=1..}] at @s run function four_elements:player/on_use

# Reset right click scoreboard
scoreboard players set @a[scores={fe_use=1..}] fe_use 0
