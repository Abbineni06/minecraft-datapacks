execute if score @s fe_menu matches 1.. run function four_elements:menu
scoreboard players set @s[scores={fe_menu=1..}] fe_menu 0

execute if score @s fe_get_fire matches 1.. run loot give @s loot four_elements:item/fire
scoreboard players set @s[scores={fe_get_fire=1..}] fe_get_fire 0

execute if score @s fe_get_ice matches 1.. run loot give @s loot four_elements:item/ice
scoreboard players set @s[scores={fe_get_ice=1..}] fe_get_ice 0

execute if score @s fe_get_lightning matches 1.. run loot give @s loot four_elements:item/lightning
scoreboard players set @s[scores={fe_get_lightning=1..}] fe_get_lightning 0

execute if score @s fe_get_earth matches 1.. run loot give @s loot four_elements:item/earth
scoreboard players set @s[scores={fe_get_earth=1..}] fe_get_earth 0
