# Check cooldown
execute if score @s fe_cd_fire matches 1.. run title @s actionbar ["",{"text":"🔥 Fire is recharging! (","color":"red"},{"score":{"name":"@s","objective":"fe_cd_fire"},"color":"yellow"},{"text":" ticks)","color":"red"}]
execute if score @s fe_cd_fire matches 1.. run return 0

# Apply 6 second cooldown (120 ticks)
scoreboard players set @s fe_cd_fire 120

# FX
playsound minecraft:entity.blaze.shoot master @s ~ ~ ~ 1.0 0.8
playsound minecraft:item.firecharge.use master @s ~ ~ ~ 1.0 1.2
particle minecraft:flame ~ ~1 ~ 1.5 0.5 1.5 0.1 80 normal
particle minecraft:lava ~ ~1 ~ 1.0 0.5 1.0 0.1 30 normal

# Ignite and damage all hostile mobs within 7 blocks
execute at @s as @e[distance=..7,type=#minecraft:skeletons] run function four_elements:ability/sub/burn_target
execute at @s as @e[distance=..7,type=#minecraft:zombies] run function four_elements:ability/sub/burn_target
execute at @s as @e[distance=..7,type=minecraft:spider] run function four_elements:ability/sub/burn_target
execute at @s as @e[distance=..7,type=minecraft:cave_spider] run function four_elements:ability/sub/burn_target
execute at @s as @e[distance=..7,type=minecraft:creeper] run function four_elements:ability/sub/burn_target
execute at @s as @e[distance=..7,type=minecraft:enderman] run function four_elements:ability/sub/burn_target
execute at @s as @e[distance=..7,type=minecraft:witch] run function four_elements:ability/sub/burn_target

title @s actionbar ["",{"text":"🔥 INFERNO BURST DETONATED! 🔥","color":"gold","bold":true}]
