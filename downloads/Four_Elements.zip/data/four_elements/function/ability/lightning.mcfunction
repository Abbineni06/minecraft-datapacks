# Check cooldown
execute if score @s fe_cd_lightning matches 1.. run title @s actionbar ["",{"text":"⚡ Lightning is recharging! (","color":"yellow"},{"score":{"name":"@s","objective":"fe_cd_lightning"},"color":"yellow"},{"text":" ticks)","color":"yellow"}]
execute if score @s fe_cd_lightning matches 1.. run return 0

# Apply 10 second cooldown (200 ticks)
scoreboard players set @s fe_cd_lightning 200

# FX
playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 1.0 1.2
particle minecraft:electric_spark ~ ~1 ~ 1.0 0.5 1.0 0.2 60 normal

# Target up to 3 nearby hostiles within 16 blocks and strike them
execute at @s as @e[distance=1..16,type=#minecraft:skeletons,limit=3,sort=nearest] run function four_elements:ability/sub/shock_target
execute at @s as @e[distance=1..16,type=#minecraft:zombies,limit=3,sort=nearest] run function four_elements:ability/sub/shock_target
execute at @s as @e[distance=1..16,type=minecraft:spider,limit=3,sort=nearest] run function four_elements:ability/sub/shock_target
execute at @s as @e[distance=1..16,type=minecraft:creeper,limit=3,sort=nearest] run function four_elements:ability/sub/shock_target

title @s actionbar ["",{"text":"⚡ CHAIN LIGHTNING STRIKE! ⚡","color":"yellow","bold":true}]
