# Check cooldown
execute if score @s fe_cd_ice matches 1.. run title @s actionbar ["",{"text":"❄️ Ice is recharging! (","color":"aqua"},{"score":{"name":"@s","objective":"fe_cd_ice"},"color":"yellow"},{"text":" ticks)","color":"aqua"}]
execute if score @s fe_cd_ice matches 1.. run return 0

# Apply 8 second cooldown (160 ticks)
scoreboard players set @s fe_cd_ice 160

# FX
playsound minecraft:block.glass.break master @s ~ ~ ~ 1.0 0.8
playsound minecraft:entity.player.hurt_freeze master @s ~ ~ ~ 1.0 1.2
particle minecraft:snowflake ~ ~1 ~ 1.5 0.6 1.5 0.1 100 normal
particle minecraft:item_snowball ~ ~1 ~ 1.0 0.5 1.0 0.1 40 normal

# Slow nearby hostiles and weaken them
execute at @s as @e[distance=..8,type=#minecraft:skeletons] run function four_elements:ability/sub/freeze_target
execute at @s as @e[distance=..8,type=#minecraft:zombies] run function four_elements:ability/sub/freeze_target
execute at @s as @e[distance=..8,type=minecraft:spider] run function four_elements:ability/sub/freeze_target
execute at @s as @e[distance=..8,type=minecraft:cave_spider] run function four_elements:ability/sub/freeze_target
execute at @s as @e[distance=..8,type=minecraft:creeper] run function four_elements:ability/sub/freeze_target
execute at @s as @e[distance=..8,type=minecraft:enderman] run function four_elements:ability/sub/freeze_target

# Grant ice shield (Resistance II for 6 seconds) to caster
effect give @s minecraft:resistance 6 1 true

title @s actionbar ["",{"text":"❄️ FROST NOVA & ICE SHIELD ACTIVATED! ❄️","color":"aqua","bold":true}]
