# Check cooldown
execute if score @s fe_cd_earth matches 1.. run title @s actionbar ["",{"text":"🌍 Earth is recharging! (","color":"green"},{"score":{"name":"@s","objective":"fe_cd_earth"},"color":"yellow"},{"text":" ticks)","color":"green"}]
execute if score @s fe_cd_earth matches 1.. run return 0

# Apply 8 second cooldown (160 ticks)
scoreboard players set @s fe_cd_earth 160

# FX
playsound minecraft:block.anvil.land master @s ~ ~ ~ 1.0 0.8
particle minecraft:dust_plume ~ ~ ~ 1.5 0.2 1.5 0.1 60 normal
particle minecraft:cloud ~ ~ ~ 1.5 0.3 1.5 0.1 40 normal

# Shockwave knockback on hostiles
execute at @s as @e[distance=..8,type=#minecraft:skeletons] run function four_elements:ability/sub/earth_target
execute at @s as @e[distance=..8,type=#minecraft:zombies] run function four_elements:ability/sub/earth_target
execute at @s as @e[distance=..8,type=minecraft:spider] run function four_elements:ability/sub/earth_target
execute at @s as @e[distance=..8,type=minecraft:creeper] run function four_elements:ability/sub/earth_target

# Grant Absorption II for 12 seconds
effect give @s minecraft:absorption 12 1 true

title @s actionbar ["",{"text":"🌍 GROUND SHOCKWAVE DETONATED! 🌍","color":"dark_green","bold":true}]
