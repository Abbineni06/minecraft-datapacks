effect give @s minecraft:slowness 8 3 true
effect give @s minecraft:weakness 8 1 true
damage @s 4 minecraft:freeze by @p
particle minecraft:snowflake ~ ~1 ~ 0.3 0.5 0.3 0.05 20 normal
