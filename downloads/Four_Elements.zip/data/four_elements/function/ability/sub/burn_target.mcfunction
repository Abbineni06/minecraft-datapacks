damage @s 8 minecraft:on_fire by @p
data modify entity @s Fire set value 160s
particle minecraft:flame ~ ~1 ~ 0.3 0.5 0.3 0.05 15 normal
