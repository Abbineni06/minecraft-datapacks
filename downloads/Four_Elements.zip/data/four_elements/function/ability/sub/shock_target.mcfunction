damage @s 12 minecraft:lightning_bolt by @p
particle minecraft:electric_spark ~ ~1 ~ 0.5 0.8 0.5 0.1 30 normal
playsound minecraft:entity.lightning_bolt.impact master @s ~ ~ ~ 1.0 1.0
