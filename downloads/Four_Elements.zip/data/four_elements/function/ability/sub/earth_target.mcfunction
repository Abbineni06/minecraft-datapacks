damage @s 8 minecraft:generic by @p
effect give @s minecraft:levitation 1 4 true
particle minecraft:dust_plume ~ ~ ~ 0.5 0.5 0.5 0.1 20 normal
