execute if items entity @s weapon.mainhand *[custom_data~{four_elements:true,element:"fire"}] run function four_elements:ability/fire
execute if items entity @s weapon.mainhand *[custom_data~{four_elements:true,element:"ice"}] run function four_elements:ability/ice
execute if items entity @s weapon.mainhand *[custom_data~{four_elements:true,element:"lightning"}] run function four_elements:ability/lightning
execute if items entity @s weapon.mainhand *[custom_data~{four_elements:true,element:"earth"}] run function four_elements:ability/earth
