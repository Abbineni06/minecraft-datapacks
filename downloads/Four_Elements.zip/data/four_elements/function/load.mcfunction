# Four Elements System Initialization
scoreboard objectives add fe_use minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add fe_cd_fire dummy
scoreboard objectives add fe_cd_ice dummy
scoreboard objectives add fe_cd_lightning dummy
scoreboard objectives add fe_cd_earth dummy
scoreboard objectives add fe_menu trigger
scoreboard objectives add fe_get_fire trigger
scoreboard objectives add fe_get_ice trigger
scoreboard objectives add fe_get_lightning trigger
scoreboard objectives add fe_get_earth trigger

# Enable triggers for players
scoreboard players enable @a fe_menu
scoreboard players enable @a fe_get_fire
scoreboard players enable @a fe_get_ice
scoreboard players enable @a fe_get_lightning
scoreboard players enable @a fe_get_earth

tellraw @a ["",{"text":"🔮 [Four Elements] ","color":"gold","bold":true},{"text":"Datapack active! Click ","color":"yellow"},{"text":"[Select Elements]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger fe_menu"},"hoverEvent":{"action":"show_text","contents":"Open element selection menu"}},{"text":" to claim your elemental relics!","color":"yellow"}]
