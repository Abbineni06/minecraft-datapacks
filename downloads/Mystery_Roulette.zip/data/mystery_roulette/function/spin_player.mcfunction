# Generate random roll 1..100
execute store result score @s mr_roll run random value 1..100

# Dispatch based on roll weight
# Common: 1..40 (40%)
execute if score @s mr_roll matches 1..40 run function mystery_roulette:reward/tier1_common

# Uncommon: 41..65 (25%)
execute if score @s mr_roll matches 41..65 run function mystery_roulette:reward/tier2_uncommon

# Rare: 66..83 (18%)
execute if score @s mr_roll matches 66..83 run function mystery_roulette:reward/tier3_rare

# Epic: 84..93 (10%)
execute if score @s mr_roll matches 84..93 run function mystery_roulette:reward/tier4_epic

# Legendary: 94..98 (5%)
execute if score @s mr_roll matches 94..98 run function mystery_roulette:reward/tier5_legendary

# Mythic: 99..100 (2%)
execute if score @s mr_roll matches 99..100 run function mystery_roulette:reward/tier6_mythic
