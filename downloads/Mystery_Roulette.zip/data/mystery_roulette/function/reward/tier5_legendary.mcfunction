# Tier 5 Legendary Reward
loot give @s loot mystery_roulette:tier5_legendary
playsound minecraft:entity.ender_dragon.growl player @a ~ ~ ~ 1.0 1.5
title @s subtitle ["",{"text":"★ TIER V: LEGENDARY FORTUNE! ★","color":"gold","bold":true}]
tellraw @a ["",{"text":"👑 [Mystery Roulette] ","color":"gold","bold":true},{"selector":"@s","color":"yellow","bold":true},{"text":" WON A ","color":"gold","bold":true},{"text":"★ LEGENDARY FORTUNE ITEM ★","color":"gold","bold":true},{"text":"!","color":"yellow"}]
particle minecraft:totem_of_undying ~ ~1 ~ 1.0 1.0 1.0 0.2 100
particle minecraft:firework ~ ~1 ~ 0.5 0.5 0.5 0.1 50
