# Tier 3 Rare Reward
loot give @s loot mystery_roulette:tier3_rare
playsound minecraft:block.amethyst_block.resonate player @s ~ ~ ~ 1.0 1.2
title @s subtitle ["",{"text":"Tier III: Rare Reward Received!","color":"aqua","bold":true}]
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"selector":"@s","color":"aqua","bold":true},{"text":" pulled a ","color":"yellow"},{"text":"Rare Reward","color":"aqua","bold":true},{"text":"!","color":"yellow"}]
particle minecraft:end_rod ~ ~1 ~ 0.5 0.5 0.5 0.1 25
