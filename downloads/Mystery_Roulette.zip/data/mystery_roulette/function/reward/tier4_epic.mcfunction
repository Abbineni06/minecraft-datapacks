# Tier 4 Epic Reward
loot give @s loot mystery_roulette:tier4_epic
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1.0 1.2
title @s subtitle ["",{"text":"Tier IV: EPIC REWARD!","color":"dark_purple","bold":true}]
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"selector":"@s","color":"light_purple","bold":true},{"text":" hit an ","color":"yellow"},{"text":"EPIC REWARD","color":"dark_purple","bold":true},{"text":"!","color":"yellow"}]
particle minecraft:portal ~ ~1 ~ 0.8 0.8 0.8 0.5 50
