# Tier 6 Mythic Reward
loot give @s loot mystery_roulette:tier6_mythic
playsound minecraft:entity.lightning_bolt.thunder player @a ~ ~ ~ 1.0 1.0
playsound minecraft:ui.toast.challenge_complete player @a ~ ~ ~ 1.0 0.8
title @s subtitle ["",{"text":"⚡ TIER VI: MYTHIC JACKPOT! ⚡","color":"light_purple","bold":true}]
tellraw @a ["",{"text":"⚡ [Mystery Roulette] JACKPOT! ","color":"light_purple","bold":true},{"selector":"@s","color":"yellow","bold":true},{"text":" UNLOCKED A ","color":"white","bold":true},{"text":"⚡ MYTHIC REWARD / SPECIAL ABILITY ⚡","color":"light_purple","bold":true},{"text":"! (2% Chance)","color":"gold"}]
particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1
particle minecraft:totem_of_undying ~ ~1 ~ 1.5 1.5 1.5 0.3 150
