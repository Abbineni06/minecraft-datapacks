# Tier 1 Common Reward
loot give @s loot mystery_roulette:tier1_common
playsound minecraft:entity.item.pickup player @s ~ ~ ~ 1.0 1.0
title @s subtitle ["",{"text":"Tier I: Common Reward Received!","color":"gray"}]
tellraw @s ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"You received a ","color":"yellow"},{"text":"Common Reward","color":"white","bold":true},{"text":"!","color":"yellow"}]
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 10
