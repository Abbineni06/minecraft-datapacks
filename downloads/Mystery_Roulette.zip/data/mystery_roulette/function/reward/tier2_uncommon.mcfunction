# Tier 2 Uncommon Reward
loot give @s loot mystery_roulette:tier2_uncommon
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1.0 1.2
title @s subtitle ["",{"text":"Tier II: Uncommon Reward Received!","color":"green","bold":true}]
tellraw @s ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"You received an ","color":"yellow"},{"text":"Uncommon Reward","color":"green","bold":true},{"text":"!","color":"yellow"}]
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.1 15
