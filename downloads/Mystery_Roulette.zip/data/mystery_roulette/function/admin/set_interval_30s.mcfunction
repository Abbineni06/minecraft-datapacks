scoreboard players set #global mr_interval 600
scoreboard players set #global mr_timer 600
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Interval set to ","color":"yellow"},{"text":"30 seconds (Fast Action)","color":"aqua","bold":true},{"text":"!","color":"yellow"}]
