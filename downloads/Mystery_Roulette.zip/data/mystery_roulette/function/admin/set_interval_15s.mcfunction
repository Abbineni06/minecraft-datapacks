scoreboard players set #global mr_interval 300
scoreboard players set #global mr_timer 300
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Interval set to ","color":"yellow"},{"text":"15 seconds (Rapid Chaos)","color":"aqua","bold":true},{"text":"!","color":"yellow"}]
