scoreboard players set #global mr_interval 1200
scoreboard players set #global mr_timer 1200
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Interval set to ","color":"yellow"},{"text":"60 seconds (Default)","color":"aqua","bold":true},{"text":"!","color":"yellow"}]
