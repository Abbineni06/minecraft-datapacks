scoreboard players set #global mr_active 1
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Countdown RESUMED.","color":"green","bold":true}]
