scoreboard objectives remove mr_timer
scoreboard objectives remove mr_interval
scoreboard objectives remove mr_active
scoreboard objectives remove mr_tmp
scoreboard objectives remove mr_roll
scoreboard objectives remove mr_sec
scoreboard objectives remove mr_use
scoreboard objectives remove mr_cd_orb
scoreboard objectives remove mr_menu
scoreboard objectives remove mr_spin
function mystery_roulette:load
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"All scores and states have been reset!","color":"yellow"}]
