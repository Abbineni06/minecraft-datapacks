scoreboard players set #global mr_interval 6000
scoreboard players set #global mr_timer 6000
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Interval set to ","color":"yellow"},{"text":"300 seconds (5 Minutes Long Pacing)","color":"aqua","bold":true},{"text":"!","color":"yellow"}]
