scoreboard players set #global mr_interval 2400
scoreboard players set #global mr_timer 2400
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Interval set to ","color":"yellow"},{"text":"120 seconds (Standard Survival)","color":"aqua","bold":true},{"text":"!","color":"yellow"}]
