scoreboard players set #global mr_active 0
tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Countdown PAUSED.","color":"red","bold":true}]
