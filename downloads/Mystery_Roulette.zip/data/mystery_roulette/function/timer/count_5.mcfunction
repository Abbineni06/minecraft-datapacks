title @a actionbar ["",{"text":"⚠️ [Mystery Roulette] Spin in: ","color":"gold","bold":true},{"text":"5s!","color":"red","bold":true}]
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1.0 0.8
