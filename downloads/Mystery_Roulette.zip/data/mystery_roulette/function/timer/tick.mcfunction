# Decrement timer
scoreboard players remove #global mr_timer 1

# Calculate remaining seconds for display (mr_timer / 20)
scoreboard players operation #global mr_sec = #global mr_timer
scoreboard players set #const_20 mr_tmp 20
scoreboard players operation #global mr_sec /= #const_20 mr_tmp

# Actionbar countdown display
execute if score #global mr_timer matches 201.. run title @a actionbar ["",{"text":"🎲 Mystery Roulette in: ","color":"gold","bold":true},{"score":{"name":"#global","objective":"mr_sec"},"color":"yellow","bold":true},{"text":"s","color":"yellow"}]

execute if score #global mr_timer matches 101..200 run title @a actionbar ["",{"text":"⏳ Mystery Roulette in: ","color":"yellow","bold":true},{"score":{"name":"#global","objective":"mr_sec"},"color":"gold","bold":true},{"text":"s!","color":"gold","bold":true}]

# Countdown ticking sound & urgent actionbar in final 5 seconds
execute if score #global mr_timer matches 100 run function mystery_roulette:timer/count_5
execute if score #global mr_timer matches 80 run function mystery_roulette:timer/count_4
execute if score #global mr_timer matches 60 run function mystery_roulette:timer/count_3
execute if score #global mr_timer matches 40 run function mystery_roulette:timer/count_2
execute if score #global mr_timer matches 20 run function mystery_roulette:timer/count_1

# Timer expired -> Trigger Global Spin!
execute if score #global mr_timer matches ..0 run function mystery_roulette:spin_all
