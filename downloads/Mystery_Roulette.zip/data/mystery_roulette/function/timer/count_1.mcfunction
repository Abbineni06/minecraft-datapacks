title @a actionbar ["",{"text":"🔥 [Mystery Roulette] Spin in: ","color":"gold","bold":true},{"text":"1s!","color":"dark_red","bold":true}]
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1.2 1.8
