# Mystery Roulette Initialization
scoreboard objectives add mr_timer dummy
scoreboard objectives add mr_interval dummy
scoreboard objectives add mr_active dummy
scoreboard objectives add mr_tmp dummy
scoreboard objectives add mr_roll dummy
scoreboard objectives add mr_sec dummy
scoreboard objectives add mr_use minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add mr_cd_orb dummy
scoreboard objectives add mr_menu trigger
scoreboard objectives add mr_spin trigger

# Default Settings (60 seconds = 1200 ticks)
execute unless score #global mr_active matches 0..1 run scoreboard players set #global mr_active 1
execute unless score #global mr_interval matches 20..72000 run scoreboard players set #global mr_interval 1200
execute unless score #global mr_timer matches 0..72000 run scoreboard players operation #global mr_timer = #global mr_interval

# Enable triggers for players
scoreboard players enable @a mr_menu
scoreboard players enable @a mr_spin

tellraw @a ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Active! Next spin in ","color":"yellow"},{"score":{"name":"#global","objective":"mr_sec"},"color":"aqua","bold":true},{"text":" seconds! Type ","color":"yellow"},{"text":"/trigger mr_menu","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger mr_menu"},"hoverEvent":{"action":"show_text","contents":"Open Mystery Roulette Menu"}},{"text":" for options.","color":"yellow"}]
