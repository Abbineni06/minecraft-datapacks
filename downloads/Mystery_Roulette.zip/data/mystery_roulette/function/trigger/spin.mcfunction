scoreboard players set @s mr_spin 0
tellraw @s ["",{"text":"🎲 [Mystery Roulette] ","color":"gold","bold":true},{"text":"Manual spin requested!","color":"yellow"}]
function mystery_roulette:spin_player
