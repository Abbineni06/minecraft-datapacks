# Reset timer
scoreboard players operation #global mr_timer = #global mr_interval

# Sound and effects for all players
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1.0 1.0
title @a title ["",{"text":"🎰 ROULETTE ROLLING! 🎰","color":"gold","bold":true}]

# Perform spin for each player
execute as @a at @s run function mystery_roulette:spin_player
