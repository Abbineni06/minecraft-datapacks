# Check cooldown (20 seconds = 400 ticks)
execute if score @s mr_cd_orb matches 1.. run return 0

# Apply cooldown
scoreboard players set @s mr_cd_orb 400

# Buffs
effect give @s minecraft:resistance 20 3 true
effect give @s minecraft:strength 20 3 true
effect give @s minecraft:regeneration 10 2 true

# Sound and effects
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 1.0 1.0
particle minecraft:electric_spark ~ ~1 ~ 1.0 1.0 1.0 0.2 60

# Strike lightning around nearby enemies (radius 15 blocks, not targeting player)
execute at @s as @e[type=!minecraft:player,type=!minecraft:item,distance=1..15] at @s run summon minecraft:lightning_bolt ~ ~ ~
execute at @s as @e[type=!minecraft:player,type=!minecraft:item,distance=1..15] run damage @s 20 minecraft:lightning_bolt by @p

tellraw @s ["",{"text":"⚡ [Orb of Thunder] ","color":"light_purple","bold":true},{"text":"Unleashed apocalyptic thunder and divine resistance! (Cooldown: 20s)","color":"aqua"}]
