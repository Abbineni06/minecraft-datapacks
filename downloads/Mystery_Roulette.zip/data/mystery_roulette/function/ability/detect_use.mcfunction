# Reset use score immediately
scoreboard players set @s mr_use 0

# Check Orb of Thunder
execute if items entity @s weapon.mainhand warped_fungus_on_a_stick[custom_data~{mr_orb:1}] run function mystery_roulette:ability/use_orb
execute if items entity @s weapon.offhand warped_fungus_on_a_stick[custom_data~{mr_orb:1}] run function mystery_roulette:ability/use_orb

# Check Jackpot Token
execute if items entity @s weapon.mainhand warped_fungus_on_a_stick[custom_data~{mr_jackpot:1}] run function mystery_roulette:ability/use_jackpot
execute if items entity @s weapon.offhand warped_fungus_on_a_stick[custom_data~{mr_jackpot:1}] run function mystery_roulette:ability/use_jackpot
