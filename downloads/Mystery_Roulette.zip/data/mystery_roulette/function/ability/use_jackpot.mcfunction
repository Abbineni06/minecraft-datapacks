# Consume 1 Jackpot Token
clear @s warped_fungus_on_a_stick[custom_data~{mr_jackpot:1}] 1

# Trigger instant high-tier spin!
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.2
title @s title ["",{"text":"🎰 JACKPOT BONUS SPIN! 🎰","color":"gold","bold":true}]

# Roll 66..100 (Guarantees Rare, Epic, Legendary, or Mythic!)
execute store result score @s mr_roll run random value 66..100

execute if score @s mr_roll matches 66..83 run function mystery_roulette:reward/tier3_rare
execute if score @s mr_roll matches 84..93 run function mystery_roulette:reward/tier4_epic
execute if score @s mr_roll matches 94..98 run function mystery_roulette:reward/tier5_legendary
execute if score @s mr_roll matches 99..100 run function mystery_roulette:reward/tier6_mythic
