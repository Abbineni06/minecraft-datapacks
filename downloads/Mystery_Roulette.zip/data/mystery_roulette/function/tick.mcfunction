# Mystery Roulette Main Tick
# Maintain triggers
scoreboard players enable @a mr_menu
scoreboard players enable @a mr_spin

# Handle Menu Triggers
execute as @a[scores={mr_menu=1..}] at @s run function mystery_roulette:trigger/menu
execute as @a[scores={mr_spin=1..}] at @s run function mystery_roulette:trigger/spin

# Handle Custom Usable Item Abilities
execute as @a[scores={mr_use=1..}] at @s run function mystery_roulette:ability/detect_use

# Decrement ability cooldowns
execute as @a[scores={mr_cd_orb=1..}] run scoreboard players remove @s mr_cd_orb 1

# Check if roulette is active
execute if score #global mr_active matches 1 run function mystery_roulette:timer/tick
