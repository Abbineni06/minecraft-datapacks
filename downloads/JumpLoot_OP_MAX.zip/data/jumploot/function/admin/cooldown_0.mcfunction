scoreboard players set #global jumploot_cfg_cd 0
tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Cooldown set to ","color":"yellow"},{"text":"0 ticks (Instant / Every Jump)","color":"aqua","bold":true},{"text":".","color":"yellow"}]
