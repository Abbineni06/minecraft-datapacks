scoreboard players set #global jumploot_cfg_cd 20
tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Cooldown set to ","color":"yellow"},{"text":"20 ticks (1.0 second)","color":"aqua","bold":true},{"text":".","color":"yellow"}]
