tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Granting all 8 Named Artifacts and Ultimate Protection Set...","color":"light_purple"}]
loot give @s loot jumploot:special/voidbreaker
loot give @s loot jumploot:special/solar_pickaxe
loot give @s loot jumploot:special/godslayer_axe
loot give @s loot jumploot:special/infinity_bow
loot give @s loot jumploot:special/titan_mace
loot give @s loot jumploot:special/eternal_trident
loot give @s loot jumploot:special/dragonheart_armor
loot give @s loot jumploot:special/skyfall_boots
loot give @s loot jumploot:special/ultimate_protection_set
