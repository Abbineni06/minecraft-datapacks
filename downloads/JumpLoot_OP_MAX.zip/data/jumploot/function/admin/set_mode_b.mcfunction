scoreboard players set @s jumploot_mode 2
scoreboard players set #global jumploot_mode 2
tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Mode switched to ","color":"yellow"},{"text":"Mode B (Beyond-Survival OP Levels 255)","color":"dark_red","bold":true},{"text":"! MAX-LEVEL god enchantments are now active!","color":"yellow"}]
