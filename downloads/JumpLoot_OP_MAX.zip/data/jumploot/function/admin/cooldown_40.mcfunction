scoreboard players set #global jumploot_cfg_cd 40
tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Cooldown set to ","color":"yellow"},{"text":"40 ticks (2.0 seconds)","color":"aqua","bold":true},{"text":".","color":"yellow"}]
