execute if score @s jumploot_mode matches 1 run function jumploot:admin/set_mode_b
execute if score @s jumploot_mode matches 2 run function jumploot:admin/set_mode_a
