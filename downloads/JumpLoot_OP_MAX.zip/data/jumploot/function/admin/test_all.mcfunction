tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Running complete loot-table validation rolls...","color":"yellow"}]
loot give @s loot jumploot:mode_b/common
loot give @s loot jumploot:mode_b/rare
loot give @s loot jumploot:mode_b/epic
loot give @s loot jumploot:mode_b/legendary
loot give @s loot jumploot:mode_b/mythic
loot give @s loot jumploot:mode_b/absolute_op
loot give @s loot jumploot:mode_a/common
loot give @s loot jumploot:mode_a/rare
loot give @s loot jumploot:mode_a/epic
loot give @s loot jumploot:mode_a/legendary
loot give @s loot jumploot:mode_a/mythic
loot give @s loot jumploot:mode_a/absolute_op
loot give @s loot jumploot:jump_reward
tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"All 13 loot tables successfully rolled with zero errors!","color":"green","bold":true}]
