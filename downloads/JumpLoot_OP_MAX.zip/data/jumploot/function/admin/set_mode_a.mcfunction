scoreboard players set @s jumploot_mode 1
scoreboard players set #global jumploot_mode 1
tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Mode switched to ","color":"yellow"},{"text":"Mode A (Maximum Survival Levels)","color":"green","bold":true},{"text":". Normal survival enchantment caps are now active.","color":"yellow"}]
