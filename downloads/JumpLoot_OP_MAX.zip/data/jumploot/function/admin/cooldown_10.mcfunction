scoreboard players set #global jumploot_cfg_cd 10
tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Cooldown set to ","color":"yellow"},{"text":"10 ticks (0.5 seconds)","color":"aqua","bold":true},{"text":".","color":"yellow"}]
