# JumpLoot OP - Initialization
scoreboard objectives add jumploot_jump minecraft.custom:minecraft.jump
scoreboard objectives add jumploot_cd dummy
scoreboard objectives add jumploot_mode dummy
scoreboard objectives add jumploot_total dummy
scoreboard objectives add jumploot_tmp dummy
scoreboard objectives add jumploot_cfg_cd dummy
scoreboard objectives add jumploot_cfg_snd dummy
scoreboard objectives add jumploot_cfg_prt dummy
scoreboard objectives add jumploot_cfg_bar dummy

# Player Survival triggers
scoreboard objectives add jumploot_menu trigger
scoreboard objectives add jumploot_toggle trigger
scoreboard objectives add jumploot_roll trigger
scoreboard objectives add jumploot_cd_trg trigger

# Default global configurations
execute unless score #global jumploot_cfg_cd matches 0.. run scoreboard players set #global jumploot_cfg_cd 0
execute unless score #global jumploot_cfg_snd matches 0.. run scoreboard players set #global jumploot_cfg_snd 1
execute unless score #global jumploot_cfg_prt matches 0.. run scoreboard players set #global jumploot_cfg_prt 1
execute unless score #global jumploot_cfg_bar matches 0.. run scoreboard players set #global jumploot_cfg_bar 1
execute unless score #global jumploot_mode matches 1..2 run scoreboard players set #global jumploot_mode 2

# Enable triggers for all current players
scoreboard players enable @a jumploot_menu
scoreboard players enable @a jumploot_toggle
scoreboard players enable @a jumploot_roll
scoreboard players enable @a jumploot_cd_trg

tellraw @a ["",{"text":"⚡ [JumpLoot OP] ","color":"gold","bold":true},{"text":"MAX LEVEL EDITION successfully loaded! Jump to receive god-tier loot! ","color":"yellow"},{"text":"[Open Menu]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/function jumploot:admin/menu"},"hoverEvent":{"action":"show_text","contents":"Click to open JumpLoot Settings Menu"}}]
