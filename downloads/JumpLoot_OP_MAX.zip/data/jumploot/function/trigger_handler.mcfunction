# Check if player activated menu trigger
execute if score @s jumploot_menu matches 1.. run function jumploot:admin/menu
scoreboard players set @s[scores={jumploot_menu=1..}] jumploot_menu 0

# Check toggle mode trigger
execute if score @s jumploot_toggle matches 1.. run function jumploot:admin/toggle_mode
scoreboard players set @s[scores={jumploot_toggle=1..}] jumploot_toggle 0

# Check test roll trigger
execute if score @s jumploot_roll matches 1.. run function jumploot:test
scoreboard players set @s[scores={jumploot_roll=1..}] jumploot_roll 0

# Check cooldown trigger
execute if score @s jumploot_cd_trg matches 1.. run scoreboard players operation #global jumploot_cfg_cd = @s jumploot_cd_trg
execute if score @s jumploot_cd_trg matches 1.. run tellraw @s ["",{"text":"[JumpLoot] ","color":"gold","bold":true},{"text":"Global cooldown set to ","color":"yellow"},{"score":{"name":"#global","objective":"jumploot_cfg_cd"},"color":"aqua"},{"text":" ticks.","color":"yellow"}]
scoreboard players set @s[scores={jumploot_cd_trg=1..}] jumploot_cd_trg 0
