# Mode A: Roll a number between 1 and 1000 for survival tiers
execute store result score #roll jumploot_tmp run random value 1..1000

execute if score #roll jumploot_tmp matches 1..450 run function jumploot:tier/common
execute if score #roll jumploot_tmp matches 451..750 run function jumploot:tier/rare
execute if score #roll jumploot_tmp matches 751..900 run function jumploot:tier/epic
execute if score #roll jumploot_tmp matches 901..970 run function jumploot:tier/legendary
execute if score #roll jumploot_tmp matches 971..995 run function jumploot:tier/mythic
execute if score #roll jumploot_tmp matches 996..1000 run function jumploot:tier/absolute_op
