# Roll a number between 1 and 1000
execute store result score #roll jumploot_tmp run random value 1..1000

# 1..450 (45%) -> Common
execute if score #roll jumploot_tmp matches 1..450 run function jumploot:tier/common

# 451..750 (30%) -> Rare
execute if score #roll jumploot_tmp matches 451..750 run function jumploot:tier/rare

# 751..900 (15%) -> Epic
execute if score #roll jumploot_tmp matches 751..900 run function jumploot:tier/epic

# 901..970 (7%) -> Legendary
execute if score #roll jumploot_tmp matches 901..970 run function jumploot:tier/legendary

# 971..995 (2.5%) -> Mythic
execute if score #roll jumploot_tmp matches 971..995 run function jumploot:tier/mythic

# 996..1000 (0.5%) -> ABSOLUTE OP
execute if score #roll jumploot_tmp matches 996..1000 run function jumploot:tier/absolute_op
