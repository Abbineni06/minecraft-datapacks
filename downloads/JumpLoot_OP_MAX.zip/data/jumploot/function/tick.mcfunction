# Keep triggers enabled for all players
scoreboard players enable @a jumploot_menu
scoreboard players enable @a jumploot_toggle
scoreboard players enable @a jumploot_roll
scoreboard players enable @a jumploot_cd_trg

# Handle triggers
execute as @a run function jumploot:trigger_handler

# Decrement player cooldowns
scoreboard players remove @a[scores={jumploot_cd=1..}] jumploot_cd 1

# Detect jumps
execute as @a[scores={jumploot_jump=1..}] at @s run function jumploot:on_jump
