# Reset jump score immediately to prevent duplicate runs
scoreboard players set @s jumploot_jump 0

# Check cooldown: if cooldown > 0, stop
execute if score @s jumploot_cd matches 1.. run return 0

# Set cooldown from config
scoreboard players operation @s jumploot_cd = #global jumploot_cfg_cd

# Increment total jumps stat
scoreboard players add @s jumploot_total 1

# Sync player mode if not set
execute unless score @s jumploot_mode matches 1..2 run scoreboard players operation @s jumploot_mode = #global jumploot_mode

# Execute reward roll based on active mode
execute if score @s jumploot_mode matches 1 run function jumploot:roll_mode_a
execute unless score @s jumploot_mode matches 1 run function jumploot:roll_mode_b
