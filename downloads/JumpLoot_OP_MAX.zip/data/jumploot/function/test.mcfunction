tellraw @s ["",{"text":"[JumpLoot OP] ","color":"gold","bold":true},{"text":"Triggering test jump reward roll...","color":"yellow"}]
execute if score @s jumploot_mode matches 1 run function jumploot:roll_mode_a
execute unless score @s jumploot_mode matches 1 run function jumploot:roll_mode_b
