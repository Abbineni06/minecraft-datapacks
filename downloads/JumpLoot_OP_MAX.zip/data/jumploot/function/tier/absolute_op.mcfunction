execute if score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_a/absolute_op
execute unless score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_b/absolute_op

execute if score #global jumploot_cfg_bar matches 1 run title @s actionbar ["",{"text":"☠ ABSOLUTE OP! ","color":"dark_red","bold":true},{"text":"✦ TRANSCENDENT GOD-TIER REWARD ✦","color":"gold","bold":true}]
tellraw @a ["",{"text":"⚡ [JumpLoot] ","color":"gold","bold":true},{"selector":"@s","color":"aqua","bold":true},{"text":" has summoned an ","color":"yellow"},{"text":"[ABSOLUTE OP TRANSCENDENT REWARD]","color":"dark_red","bold":true,"underlined":true},{"text":" from a leap of destiny!","color":"yellow"}]
execute if score #global jumploot_cfg_snd matches 1 run playsound minecraft:item.totem.use master @s ~ ~ ~ 1.0 1.0
execute if score #global jumploot_cfg_snd matches 1 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.5
execute if score #global jumploot_cfg_prt matches 1 run particle minecraft:totem_of_undying ~ ~1 ~ 0.7 1.0 0.7 0.3 60 normal
execute if score #global jumploot_cfg_prt matches 1 run particle minecraft:electric_spark ~ ~1 ~ 0.5 0.8 0.5 0.15 40 normal
