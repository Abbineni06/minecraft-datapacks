execute if score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_a/rare
execute unless score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_b/rare

execute if score #global jumploot_cfg_bar matches 1 run title @s actionbar ["",{"text":"⚡ JUMPLOOT ","color":"dark_aqua","bold":true},{"text":"[","color":"dark_gray"},{"text":"RARE REWARD","color":"aqua","bold":true},{"text":"]","color":"dark_gray"}]
execute if score #global jumploot_cfg_snd matches 1 run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1.0 1.4
execute if score #global jumploot_cfg_prt matches 1 run particle minecraft:wax_off ~ ~1 ~ 0.4 0.5 0.4 0.1 20 normal
