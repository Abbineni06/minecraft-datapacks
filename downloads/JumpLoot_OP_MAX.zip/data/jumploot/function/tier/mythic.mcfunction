execute if score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_a/mythic
execute unless score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_b/mythic

execute if score #global jumploot_cfg_bar matches 1 run title @s actionbar ["",{"text":"✪ JUMPLOOT ","color":"dark_red","bold":true},{"text":"[","color":"gold"},{"text":"MYTHIC ARTIFACT UNLOCKED","color":"red","bold":true},{"text":"]","color":"gold"},{"text":" ✪","color":"dark_red","bold":true}]
tellraw @s ["",{"text":"[JumpLoot] ","color":"gold","bold":true},{"text":"✦ You unsealed an ancient ","color":"yellow"},{"text":"MYTHIC ARTIFACT","color":"dark_red","bold":true},{"text":" from your jump!","color":"yellow"}]
execute if score #global jumploot_cfg_snd matches 1 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.2
execute if score #global jumploot_cfg_prt matches 1 run particle minecraft:dragon_breath ~ ~1 ~ 0.6 0.8 0.6 0.1 40 normal
