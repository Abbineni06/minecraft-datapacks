execute if score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_a/legendary
execute unless score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_b/legendary

execute if score #global jumploot_cfg_bar matches 1 run title @s actionbar ["",{"text":"★ JUMPLOOT ","color":"gold","bold":true},{"text":"[","color":"dark_gray"},{"text":"LEGENDARY LEVEL 255","color":"yellow","bold":true},{"text":"]","color":"dark_gray"},{"text":" ★","color":"gold","bold":true}]
execute if score #global jumploot_cfg_snd matches 1 run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1.0 1.3
execute if score #global jumploot_cfg_prt matches 1 run particle minecraft:end_rod ~ ~1 ~ 0.5 0.7 0.5 0.1 35 normal
