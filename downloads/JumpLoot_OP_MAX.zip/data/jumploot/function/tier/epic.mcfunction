execute if score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_a/epic
execute unless score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_b/epic

execute if score #global jumploot_cfg_bar matches 1 run title @s actionbar ["",{"text":"⚡ JUMPLOOT ","color":"dark_purple","bold":true},{"text":"[","color":"dark_gray"},{"text":"EPIC REWARD","color":"light_purple","bold":true},{"text":"]","color":"dark_gray"}]
execute if score #global jumploot_cfg_snd matches 1 run playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1.0 1.2
execute if score #global jumploot_cfg_prt matches 1 run particle minecraft:portal ~ ~1 ~ 0.5 0.6 0.5 0.2 30 normal
