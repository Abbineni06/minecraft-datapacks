execute if score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_a/common
execute unless score @s jumploot_mode matches 1 run loot give @s loot jumploot:mode_b/common

execute if score #global jumploot_cfg_bar matches 1 run title @s actionbar ["",{"text":"⚡ JUMPLOOT ","color":"green","bold":true},{"text":"[","color":"dark_gray"},{"text":"COMMON REWARD","color":"white","bold":true},{"text":"]","color":"dark_gray"}]
execute if score #global jumploot_cfg_snd matches 1 run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 1.0 1.2
execute if score #global jumploot_cfg_prt matches 1 run particle minecraft:happy_villager ~ ~1 ~ 0.3 0.4 0.3 0.1 15 normal
