# 🎮 Minecraft Datapack Studio

**A Master Collection of Five Independent, Production-Grade Minecraft Java Edition Datapacks**  
*Built for Minecraft Java Edition 26.2 (Native Pack Format 107) with Full Compatibility for 1.21.1+ through 26.3*

---

## 🌟 Studio Showcase

Minecraft Datapack Studio is an elite suite of five independent, fully playable datapacks designed to dramatically enhance Minecraft Java Edition survival, progression, and combat.

| # | Datapack | Version | Namespace | Core Mechanic & Highlights | Download |
|---|---|---|---|---|---|
| **01** | **[Evolution Sword](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/01-Evolution-Sword/README.md)** | `1.0.0` | `evo_sword` | 10-tier living sword that evolves as you kill mobs, growing in power, lore, and custom enchantments. | [`Evolution_Sword.zip`](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/DIST/Evolution_Sword.zip) |
| **02** | **[Four Elements](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/02-Four-Elements/README.md)** | `1.0.0` | `four_elements` | 4 active elemental relics (Fire, Ice, Lightning, Earth) with right-click spellcasting and cooldown timers. | [`Four_Elements.zip`](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/DIST/Four_Elements.zip) |
| **03** | **[Cursed Blocks](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/03-Cursed-Blocks/README.md)** | `1.0.0` | `cursed_blocks` | Unpredictable high-stakes mining events: rewards, hazardous traps, mob swarms, and the Crypt Guardian mini-boss. | [`Cursed_Blocks.zip`](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/DIST/Cursed_Blocks.zip) |
| **04** | **[Reality Gauntlet](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/04-Reality-Gauntlet/README.md)** | `1.0.0` | `reality_gauntlet` | Hunt 6 cosmic gems to wield reality-bending spells. Combine them to perform the ultimate **Cosmic Snap**. | [`Reality_Gauntlet.zip`](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/DIST/Reality_Gauntlet.zip) |
| **05** | **[Mystery Roulette](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/05-Mystery-Roulette/README.md)** | `1.0.0` | `mystery_roulette` | Automated countdown fortune wheel granting 6 tiers of loot and game-changing active relics every 60 seconds. | [`Mystery_Roulette.zip`](file:///Users/saikiran/Downloads/DATAPACKS/Minecraft-Datapack-Studio/DIST/Mystery_Roulette.zip) |

---

## 💻 Installation Guide for TLauncher on macOS

This step-by-step guide is designed for macOS users running Minecraft Java Edition via TLauncher or standard official launchers on Apple Silicon (M1/M2/M3/M4) and Intel Macs.

### Method A: Installing into an Existing World (Quick & Easy)

1. **Locate your Minecraft Application Directory on macOS**:
   - Open **Finder**.
   - Press the keyboard shortcut: **`Cmd + Shift + G`** (Go to Folder).
   - Enter the following path and press Enter:
     ```text
     ~/Library/Application Support/minecraft
     ```
2. **Navigate to your World's Datapacks Folder**:
   - Open the **`saves/`** folder.
   - Click into your target world folder (e.g., `New World`, `Survival`).
   - Open the **`datapacks/`** folder inside that world:
     ```text
     ~/Library/Application Support/minecraft/saves/<YOUR_WORLD_NAME>/datapacks
     ```
3. **Copy the Datapack ZIP File**:
   - Drag and drop your desired release ZIP file(s) directly into `datapacks/`:
     - `Evolution_Sword.zip`
     - `Four_Elements.zip`
     - `Cursed_Blocks.zip`
     - `Reality_Gauntlet.zip`
     - `Mystery_Roulette.zip`
   > [!IMPORTANT]
   > Do **NOT** unzip the file! Minecraft Java Edition reads `.zip` archives directly from the root.
4. **Activate In-Game**:
   - Open Minecraft and enter your world.
   - Open the in-game chat (`T`) and type:
     ```text
     /reload
     ```
   - Verify installation by running:
     ```text
     /datapack list enabled
     ```
   - You will see `[file/<datapack_name>.zip (world)]` listed in green!

---

### Method B: Installing During World Creation

1. In the Minecraft main menu, click **Singleplayer** → **Create New World**.
2. Click the **More** tab (or **Data Packs** button).
3. Click **Open Pack Folder**. Finder will open the temporary datapack folder.
4. Drag and drop any or all studio ZIP files into this folder.
5. Return to Minecraft; hover over the datapack in the **Available** column (left side) and click the arrow to move it to the **Selected** column (right side).
6. Click **Done** and proceed to create your world!

---

## 🎮 Player Quick-Start Commands (Non-OP Permitted)

Every datapack in Minecraft Datapack Studio is engineered with vanilla scoreboard triggers, allowing players without server OP permissions to access menus and starter features in Survival mode:

| Datapack | Player Command | Function |
|---|---|---|
| **Evolution Sword** | `/trigger evo_give` | Claims or equips your living Evolution Sword. |
| **Evolution Sword** | `/trigger evo_menu` | Displays current weapon stage, kill count, and stats. |
| **Four Elements** | `/trigger fe_menu` | Opens the elemental control panel to choose your starter relic. |
| **Cursed Blocks** | `/trigger cb_menu` | Opens the Cursed Blocks settings and event guide. |
| **Reality Gauntlet** | `/trigger rg_menu` | Displays gathered gems and gauntlet status. |
| **Mystery Roulette** | `/trigger mr_menu` | Opens the roulette timer panel (pause, intervals, manual roll). |
| **Mystery Roulette** | `/trigger mr_spin` | Requests an instant personal roulette spin. |

---

## 👑 Admin Commands (Requires OP / Cheats Enabled)

For server administrators or map creators:

```mcfunction
# Evolution Sword Stage Control
/function evo_sword:admin/set_stage_1
/function evo_sword:admin/set_stage_10
/function evo_sword:admin/reset

# Four Elements Relics
/function four_elements:admin/give_fire
/function four_elements:admin/give_ice
/function four_elements:admin/give_lightning
/function four_elements:admin/give_earth

# Cursed Blocks Settings
/function cursed_blocks:admin/toggle_active
/function cursed_blocks:admin/toggle_safe_mode
/function cursed_blocks:admin/set_chance_50

# Reality Gauntlet & Gems
/function reality_gauntlet:admin/give_all_gems
/function reality_gauntlet:admin/give_gauntlet
/function reality_gauntlet:ability/ultimate

# Mystery Roulette Control
/function mystery_roulette:admin/spin_now
/function mystery_roulette:admin/pause
/function mystery_roulette:admin/resume
/function mystery_roulette:admin/set_interval_30s
/function mystery_roulette:admin/give_tier5
/function mystery_roulette:admin/give_tier6
```

---

## 📂 Master Directory Structure

```text
Minecraft-Datapack-Studio/
├── README.md                     <- This Master Guide & TLauncher Documentation
├── MASTER_INDEX.md               <- Full File, Function & Scoreboard Catalog
├── VERSION_COMPATIBILITY.md       <- Cross-Version Compatibility Specifications
├── RELEASE_NOTES.md              <- Official v1.0.0 Release Notes
│
├── 01-Evolution-Sword/           <- Project 1 Source, Docs & Release ZIP
│   ├── README.md
│   ├── CHANGELOG.md
│   ├── TEST_REPORT.md
│   ├── SOURCE/ (pack.mcmeta, data/evo_sword, data/minecraft)
│   ├── RELEASE/ (Evolution_Sword.zip)
│   └── DOCUMENTATION/
│
├── 02-Four-Elements/             <- Project 2 Source, Docs & Release ZIP
├── 03-Cursed-Blocks/             <- Project 3 Source, Docs & Release ZIP
├── 04-Reality-Gauntlet/          <- Project 4 Source, Docs & Release ZIP
├── 05-Mystery-Roulette/          <- Project 5 Source, Docs & Release ZIP
│
├── SHARED-TOOLS/
│   ├── validation/               <- Static & In-Game Engine Test Reports
│   └── packaging/
│
└── DIST/                         <- Final Standalone ZIP Releases & Studio Master ZIP
    ├── Evolution_Sword.zip
    ├── Four_Elements.zip
    ├── Cursed_Blocks.zip
    ├── Reality_Gauntlet.zip
    ├── Mystery_Roulette.zip
    └── Minecraft_Datapack_Studio.zip
```

---

## 🛠️ Technical Verification & Standards

- **Zero Inter-Pack Collisions**: 60 isolated scoreboard objectives with strict prefixes (`es_`, `fe_`, `cb_`, `rg_`, `mr_`).
- **Standard Objective Length**: Every scoreboard objective name is strictly <= 16 characters for maximum cross-version engine safety.
- **Dual Tag Structure**: Automatically discovered by both legacy 1.21.x (`data/minecraft/tags/functions/`) and modern 26.x (`data/minecraft/tags/function/`).
- **Engine Verified**: Tested on native Minecraft 26.2 server engine with 0 runtime errors.
