# Changelog — Cursed Blocks

## [1.0.0] - 2026-10-17
- Initial release with 4 distinct event categories and safe-mode toggle.
