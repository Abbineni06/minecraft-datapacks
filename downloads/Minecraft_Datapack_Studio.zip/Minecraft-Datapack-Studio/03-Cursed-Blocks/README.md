# Project 03: Cursed Blocks

**Namespace**: `cursed_blocks`  
**Target Version**: Minecraft Java Edition 26.2 (Compatible with 1.21.1 through 26.3)  
**Palette Identity**: Dark Purple and Crimson  

---

## 🌟 Overview
Cursed Blocks turns underground mining into a thrilling risk-and-reward gamble. Breaking core blocks (Stone, Deepslate, Coal, Iron, Gold, Diamond Ore, and Ancient Debris) has a configurable chance to trigger Rewards, Hazards, Anomalous Surprises, or Mini-Boss Encounters.

## 🎲 Event Categories
1. **Rewards (40% of triggers)**: Spawns high-value resources including Diamonds, Ancient Debris, Enchanted Golden Apples, Totems of Undying, Emeralds, and Experience.
2. **Hazards (30% of triggers)**: Darkness/Blindness curses, Poison mist, or direct kinetic damage.
3. **Surprises (20% of triggers)**: Positive anomalies like Haste II + Speed II, Jump Boost III + Slow Falling, or large XP bursts.
4. **Boss Challenge (10% of triggers)**: Awakens the **Crypt Guardian**, an armored Wither Skeleton wielding an enchanted fire blade!

## 🕹️ Commands
- `/trigger cb_menu` — Open player status and control panel.
- `/function cursed_blocks:admin/menu` — Operator control menu to adjust trigger probabilities or test individual events.
- `/function cursed_blocks:event/reward`, `/function cursed_blocks:event/hazard`, etc. — Direct event test commands.
