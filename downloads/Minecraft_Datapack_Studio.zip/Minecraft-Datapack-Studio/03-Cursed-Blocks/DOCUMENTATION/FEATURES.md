# Cursed Blocks Features

Uses vanilla `minecraft.mined:<block>` criteria with immediate tick resets, avoiding global block-raycast lag and guaranteeing accurate detection.
