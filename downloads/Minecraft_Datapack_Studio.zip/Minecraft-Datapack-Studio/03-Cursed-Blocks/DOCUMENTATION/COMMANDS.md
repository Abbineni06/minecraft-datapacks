# Cursed Blocks Commands

- `/function cursed_blocks:admin/menu`
- `/function cursed_blocks:admin/chance_<10|20|50|100>`
- `/function cursed_blocks:admin/toggle_safe_mode`
