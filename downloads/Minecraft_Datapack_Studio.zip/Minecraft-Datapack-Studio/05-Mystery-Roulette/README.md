# Mystery Roulette — Timed Chaos & Fortune Drops

**Minecraft Java Edition 26.2 & 1.21+ Datapack**

Mystery Roulette adds a high-stakes, timed fortune wheel to your Minecraft world. Every configurable interval (default: 60 seconds), the roulette wheel spins for every player, awarding anything from vital survival supplies to server-shaking mythic artifacts and active apocalyptic abilities!

---

## 🎲 Features

- **Automated Timer System**: Live actionbar countdown showing remaining seconds with color stages and audio plings during the final 5 seconds.
- **6 Dynamic Reward Tiers**:
  - **Tier I: Common (40% weight)**: Iron, cooked beef, golden carrots, arrows, logs, coal.
  - **Tier II: Uncommon (25% weight)**: Diamonds, golden apples, ender pearls, bottles o' enchanting, obsidian.
  - **Tier III: Rare (18% weight)**: Ancient debris, netherite scrap, Totem of Undying, Shulker Boxes.
  - **Tier IV: Epic (10% weight)**: Netherite ingots, Enchanted Golden Apples, Elytra, Nether Star.
  - **Tier V: Legendary (5% weight)**: Over-enchanted God Gear (Roulette Champion Greatsword, Cosmic Starlight Pickaxe, Aegis of the High Roller, Beacon).
  - **Tier VI: Mythic Abilities (2% weight)**: Game-changing active relics including the *Orb of Thunder & Destruction* and the *Golden Jackpot Token*!
- **Active Special Relics**:
  - **Orb of Thunder**: Right-click to call down a lightning barrage on all nearby hostile entities while granting Resistance IV and Strength IV!
  - **Jackpot Token**: Right-click to consume for an instant bonus roll guaranteed to be Rare tier or higher!
- **In-Game Interactive Menu**: Access full GUI configuration with `/trigger mr_menu` without needing OP permissions.
- **Full Multiplayer Support**: Simultaneously awards rewards to all players without cross-entity desync.

---

## ⚡ Quick Start

1. Drop `Mystery_Roulette.zip` into your world's `datapacks/` folder.
2. Run `/reload`.
3. The roulette countdown begins immediately! Watch your actionbar.
4. Type `/trigger mr_menu` to pause, adjust timer intervals, or trigger manual spins.
