# Changelog — Mystery Roulette

## [1.0.0] - 2026-10-17
### Added
- Complete automated countdown loop with 5 customizable presets (15s, 30s, 60s, 120s, 300s).
- 6-tier loot architecture with vanilla-weighted random probability distribution.
- Active ability system powered by warped fungus on a stick right-click detection.
- Interactive chat GUI menu (`/trigger mr_menu`) with one-click buttons.
- Full compatibility with Minecraft 26.2 (`pack_format: 107`) and Minecraft 1.21+ (`min_format: 48`).
