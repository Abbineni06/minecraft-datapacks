# Mystery Roulette — Command & Trigger Reference

## Player Triggers (Non-OP Permitted)
| Trigger | Description |
|---|---|
| `/trigger mr_menu` | Opens the interactive chat menu to toggle timer and change speed presets. |
| `/trigger mr_spin` | Requests an instant personal spin (useful in testing or custom server games). |

## Admin Commands (Requires OP / Level 2)
| Function | Description |
|---|---|
| `/function mystery_roulette:admin/spin_now` | Forces an immediate global spin for all online players and resets timer. |
| `/function mystery_roulette:admin/pause` | Pauses the roulette countdown loop. |
| `/function mystery_roulette:admin/resume` | Resumes the roulette countdown loop. |
| `/function mystery_roulette:admin/set_interval_15s` | Sets spin interval to 15 seconds (Rapid Chaos mode). |
| `/function mystery_roulette:admin/set_interval_30s` | Sets spin interval to 30 seconds. |
| `/function mystery_roulette:admin/set_interval_60s` | Sets spin interval to 60 seconds (Default). |
| `/function mystery_roulette:admin/set_interval_120s` | Sets spin interval to 120 seconds (2 minutes). |
| `/function mystery_roulette:admin/set_interval_300s` | Sets spin interval to 300 seconds (5 minutes). |
| `/function mystery_roulette:admin/give_tier1` | Grants a Tier I (Common) drop. |
| `/function mystery_roulette:admin/give_tier2` | Grants a Tier II (Uncommon) drop. |
| `/function mystery_roulette:admin/give_tier3` | Grants a Tier III (Rare) drop. |
| `/function mystery_roulette:admin/give_tier4` | Grants a Tier IV (Epic) drop. |
| `/function mystery_roulette:admin/give_tier5` | Grants a Tier V (Legendary) drop. |
| `/function mystery_roulette:admin/give_tier6` | Grants a Tier VI (Mythic) drop. |
| `/function mystery_roulette:admin/reset` | Resets all scoreboards and reinitializes pack state. |
