# Mystery Roulette — Detailed Feature Specifications

## 1. Countdown & Audio Engine
- **Normal Phase (>10s)**: Displayed as yellow text on the actionbar: `🎲 Mystery Roulette in: Xs`.
- **Warning Phase (6-10s)**: Turns gold with warning cues: `⏳ Mystery Roulette in: Xs!`.
- **Final 5-Second Countdown**:
  - `5s`: Low pitch pling (`0.8`)
  - `4s`: Mid-low pling (`1.0`)
  - `3s`: Mid pling (`1.2`)
  - `2s`: High pling (`1.4`)
  - `1s`: Highest pitch pling (`1.8`)
- **Roll Trigger (0s)**: Toast fanfare (`minecraft:ui.toast.challenge_complete`), grand title banner `🎰 ROULETTE ROLLING! 🎰`, and loot generation.

## 2. Loot Tiers & Probabilities
| Tier | Name | Weight | Notable Drops |
|---|---|---|---|
| Tier I | Common | 40% | Iron ingots (8-16), Cooked beef (16-32), Golden carrots, Arrows, Logs |
| Tier II | Uncommon | 25% | Diamonds (4-8), Golden apples (3-6), Ender pearls (6-12), XP bottles |
| Tier III | Rare | 18% | Ancient debris (2-4), Netherite scrap, Totem of Undying, Shulker Boxes |
| Tier IV | Epic | 10% | Netherite ingots (2-4), Enchanted Golden Apple, Elytra, Nether Star |
| Tier V | Legendary | 5% | Roulette Champion Greatsword (Sharpness X), Starlight Pickaxe (Efficiency X), Aegis Chestplate |
| Tier VI | Mythic | 2% | Orb of Thunder & Destruction, Golden Jackpot Token, Netherite Blocks |

## 3. Mythic Abilities
### Orb of Thunder & Destruction
- Item: Warped Fungus on a Stick with custom NBT `mr_orb: 1`.
- Mechanics: Right-click triggers lightning strikes on all hostiles within a 15-block radius, dealing 20 direct damage.
- Self Buffs: Grants Resistance IV and Strength IV for 20 seconds.
- Cooldown: 20-second internal timer prevents spam.

### Golden Jackpot Token
- Item: Warped Fungus on a Stick with custom NBT `mr_jackpot: 1`.
- Mechanics: Consumed on right-click to trigger a guaranteed high-tier spin (rolls exclusively in Rare, Epic, Legendary, or Mythic ranges).
