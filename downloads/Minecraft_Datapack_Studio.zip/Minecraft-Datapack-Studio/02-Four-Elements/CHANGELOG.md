# Changelog — Four Elements

## [1.0.0] - 2026-10-17
- Initial release with Fire, Ice, Lightning, and Earth abilities.
