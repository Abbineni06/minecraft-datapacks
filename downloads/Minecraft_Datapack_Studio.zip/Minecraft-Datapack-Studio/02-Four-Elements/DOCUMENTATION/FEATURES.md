# Four Elements Features

All four elements use vanilla right-click detection on warped fungus on a stick, guaranteeing zero-latency casting in singleplayer and multiplayer.
