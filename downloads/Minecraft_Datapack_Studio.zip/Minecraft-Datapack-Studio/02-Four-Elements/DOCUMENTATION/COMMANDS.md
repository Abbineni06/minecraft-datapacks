# Four Elements Commands

- `/function four_elements:menu`
- `/trigger fe_menu`
- `/trigger fe_get_<element>`
