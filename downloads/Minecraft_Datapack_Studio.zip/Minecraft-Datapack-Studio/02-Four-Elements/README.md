# Project 02: Four Elements

**Namespace**: `four_elements`  
**Target Version**: Minecraft Java Edition 26.2 (Compatible with 1.21.1 through 26.3)  
**Palette Identity**: Orange (Fire), Ice Blue (Ice), Yellow (Lightning), Earth Green (Earth)  

---

## 🌟 Overview
Four Elements grants players four distinct, active elemental relics. By holding and right-clicking any relic, players trigger unique spells with custom particles, sound effects, damage mechanics, and independent cooldown tracking.

## 🔮 The Four Elements
1. **Inferno Catalyst (Fire)**: Radiates a 7-block firestorm, damaging and igniting nearby hostiles for 8 seconds. (6.0s cooldown)
2. **Glacial Scepter (Ice)**: Unleashes a frost nova that slows hostile mobs by 80% (Slowness IV) and weakens them, while granting the caster Resistance II. (8.0s cooldown)
3. **Thunder Relic (Lightning)**: Smites up to 3 nearby hostiles with precision electric shock without destroying terrain. (10.0s cooldown)
4. **Quake Core (Earth)**: Detonates a ground tremor launching enemies into the air and fortifying the caster with Absorption II. (8.0s cooldown)

## 🕹️ Commands
- `/trigger fe_menu` — Open element selection menu in Survival.
- `/trigger fe_get_fire`, `fe_get_ice`, `fe_get_lightning`, `fe_get_earth` — Claim individual relics.
- `/function four_elements:menu` — Operator control menu.
