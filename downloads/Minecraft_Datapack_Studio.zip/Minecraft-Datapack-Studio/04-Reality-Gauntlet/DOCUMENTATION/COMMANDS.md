# Reality Gauntlet Commands

- `/function reality_gauntlet:admin/menu`
- `/function reality_gauntlet:admin/give_all_gems`
- `/trigger rg_menu`
