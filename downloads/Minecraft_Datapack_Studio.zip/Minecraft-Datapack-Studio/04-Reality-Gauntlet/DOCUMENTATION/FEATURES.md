# Reality Gauntlet Features

Automatically detects the 6 gems in the player's container inventory, updating the Gauntlet UI dynamically in real time.
