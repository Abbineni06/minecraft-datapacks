# Changelog — Reality Gauntlet

## [1.0.0] - 2026-10-17
- Initial release with 6 functional gems and the Cosmic Snap ultimate.
