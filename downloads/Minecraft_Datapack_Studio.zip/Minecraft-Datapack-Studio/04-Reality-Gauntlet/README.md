# Project 04: Reality Gauntlet

**Namespace**: `reality_gauntlet`  
**Target Version**: Minecraft Java Edition 26.2 (Compatible with 1.21.1 through 26.3)  
**Palette Identity**: Cosmic Purple, Cyan, and Gold  

---

## 🌟 Overview
Reality Gauntlet introduces six collectible cosmic gems and the fabled Reality Gauntlet. Each gem bestows an active supernatural spell. Once all six gems are assembled, right-clicking with the Gauntlet unlocks **The Cosmic Snap**, disintegrating half of all hostile threats and granting godly invulnerability.

## 💎 The Six Gems & Powers
1. **Space Gem (Blue)**: Spatial Warp — Instantly blinks 8 blocks forward through solid space. (5s cooldown)
2. **Time Gem (Green)**: Chrono Stasis — Freezes all nearby hostile mobs in place for 6 seconds. (12s cooldown)
3. **Storm Gem (Yellow)**: Tempest Smite — Smites nearby hostiles with precision electric shock. (10s cooldown)
4. **Life Gem (Gold)**: Vitality Surge — Restores 4 hearts, Regeneration II, and Saturation. (15s cooldown)
5. **Gravity Gem (Purple)**: Gravitational Collapse — Levitates and violently slams enemies down. (12s cooldown)
6. **Power Gem (Red)**: Cosmic Cataclysm — Radial explosion dealing 16 direct damage. (15s cooldown)
7. **The Reality Gauntlet**: Unlocks **The Cosmic Snap** when all 6 gems are owned in inventory. (60s cooldown)

## 🕹️ Commands
- `/trigger rg_menu` — Open Gauntlet menu in Survival.
- `/trigger rg_get_gauntlet` — Claim your Reality Gauntlet.
- `/function reality_gauntlet:admin/give_all_gems` — Operator shortcut to acquire all gems.
