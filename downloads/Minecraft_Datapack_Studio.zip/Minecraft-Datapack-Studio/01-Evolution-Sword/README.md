# Project 01: Evolution Sword

**Namespace**: `evo_sword`  
**Target Version**: Minecraft Java Edition 26.2 (Compatible with 1.21.1 through 26.3)  
**Palette Identity**: Purple and Gold  

---

## 🌟 Overview
Every mob defeated with your Evolution Sword feeds the weapon's cosmic core, advancing it through 10 distinct evolutionary stages with custom attributes, enchantments, and particles.

## ⚔️ The 10 Evolutionary Stages
1. **Awakening**: Starter wooden blade with basic durability. (5 kills required)
2. **Iron Soul**: Iron blade tempered with Sharpness I. (10 kills required)
3. **Emerald Edge**: Sharpness II and Looting I to gather riches. (15 kills required)
4. **Diamond Fury**: Diamond blade with Sharpness III and Looting II. (20 kills required)
5. **Nether Flame**: Netherite edge with Fire Aspect and Sharpness IV. (25 kills required)
6. **Void Hunter**: Netherite blade with Sharpness V, Fire Aspect II, Knockback I. (30 kills required)
7. **Dragon Slayer**: Infused with Sharpness VI, Smite V, and Mending. (40 kills required)
8. **Celestial Blade**: Sharpness VIII, Sweeping Edge III, Looting IV. (50 kills required)
9. **Eternal Destroyer**: Sharpness XII, Fire Aspect V, Looting V. (75 kills required)
10. **The Apex Transcendent Blade**: Ultimate Stage with Sharpness 25, Looting 10, Fire Aspect 10, Sweeping Edge 10, Unbreaking 255.

## 🕹️ Commands & Controls
- `/trigger evo_give` — Claim or recover your evolution sword at your current unlocked stage without duplicates.
- `/trigger evo_menu` — Open the interactive control panel.
- `/function evo_sword:admin/menu` — Operator control menu to select stages or simulate kills.
- `/function evo_sword:admin/reset` — Reset player progress back to Stage 1.
