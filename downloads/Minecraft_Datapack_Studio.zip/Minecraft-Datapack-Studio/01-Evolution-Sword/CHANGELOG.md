# Changelog — Evolution Sword

## [1.0.0] - 2026-10-17
- Initial release for Minecraft Java Edition 26.2 (1.21+ compatible).
- 10 distinct progression stages with custom names, lore, and component-based enchantments.
- Actionbar progress display.
- Non-OP trigger system for sword recovery and menu access.
