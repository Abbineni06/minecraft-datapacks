# Evolution Sword — Commands Reference

### Player Commands
- `/trigger evo_give`: Gives the sword corresponding to your active progression stage.
- `/trigger evo_menu`: Displays the status and interactive buttons in chat.

### Admin Commands
- `/function evo_sword:admin/menu`: Opens full operator dashboard.
- `/function evo_sword:admin/set_stage_<1..10>`: Instantly elevates the player to that stage.
- `/function evo_sword:admin/reset`: Clears progression back to 1.
- `/function evo_sword:test_kill`: Adds 1 virtual mob kill to test evolution.
