# Evolution Sword — Features & Mechanics

## 1. Mob Kill Detection
Tracks `minecraft.custom:minecraft.mob_kills`. Only triggers when the player is actively holding an item with `custom_data={evo_sword:true}` in their main hand, preventing weapon swapping exploits.

## 2. Loss & Duplication Prevention
If a player loses their sword, `/trigger evo_give` will clear any existing evolution sword before giving a replacement at their exact unlocked stage.

## 3. Death Mode Configuration
- `#global evo_death_mode = 0`: Preserve progression through death (Default).
- `#global evo_death_mode = 1`: Reset to Stage 1 upon death.
