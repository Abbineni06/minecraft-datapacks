# Minecraft Datapack Studio — Master Technical Index

This document provides a comprehensive technical reference for all 5 independent datapacks in the **Minecraft Datapack Studio** suite.

---

## 🗂️ Studio Portfolio Summary

| # | Datapack Name | Folder | ZIP Archive | Namespace | Core Mechanic | Active Abilities |
|---|---|---|---|---|---|---|
| **01** | **Evolution Sword** | `01-Evolution-Sword` | `Evolution_Sword.zip` | `evo_sword` | 10-Tier Living Weapon Progression | Kill-based Evolution, Stat Actionbar |
| **02** | **Four Elements** | `02-Four-Elements` | `Four_Elements.zip` | `four_elements` | 4 Elemental Relics | Fire Burst, Frost Nova, Chain Lightning, Shockwave |
| **03** | **Cursed Blocks** | `03-Cursed-Blocks` | `Cursed_Blocks.zip` | `cursed_blocks` | Unpredictable Mining Events | 4 Hazard/Reward Categories, Crypt Guardian Boss |
| **04** | **Reality Gauntlet** | `04-Reality-Gauntlet` | `Reality_Gauntlet.zip` | `reality_gauntlet` | 6 Cosmic Gems + Omnipotent Gauntlet | 6 Gem Abilities + The Cosmic Snap |
| **05** | **Mystery Roulette** | `05-Mystery-Roulette` | `Mystery_Roulette.zip` | `mystery_roulette` | Timed Chaos Fortune Wheel | 6 Reward Tiers + Orb of Thunder & Jackpot Token |

---

## 🛡️ Scoreboard Objectives Catalog (60 Total Objectives)

All objectives are namespaced with project-specific prefixes to prevent collisions. All names strictly adhere to the <= 16 character limit.

### 1. Evolution Sword (`evo_sword`, 8 Objectives)
- `es_kills` (`minecraft.custom:minecraft.mob_kills`): Tracks mob kills made by players.
- `es_stage` (`dummy`): Tracks the current weapon stage (1..10).
- `es_held` (`dummy`): Indicates whether the player is currently wielding an Evolution Sword.
- `es_tmp` (`dummy`): Scratchpad score for arithmetic calculations.
- `es_k_needed` (`dummy`): Total mob kills required for the next evolution threshold.
- `es_k_prog` (`dummy`): Current progress toward the next evolution threshold.
- `es_menu` (`trigger`): Interactive trigger to display sword status and stats.
- `es_claim` (`trigger`): Trigger allowing players to re-claim their living sword.

### 2. Four Elements (`four_elements`, 9 Objectives)
- `fe_use` (`minecraft.used:minecraft.warped_fungus_on_a_stick`): Detects right-click activation on relics.
- `fe_cd_fire` (`dummy`): Cooldown timer for the Fire Relic (ticks).
- `fe_cd_ice` (`dummy`): Cooldown timer for the Frost Relic (ticks).
- `fe_cd_light` (`dummy`): Cooldown timer for the Lightning Relic (ticks).
- `fe_cd_earth` (`dummy`): Cooldown timer for the Earth Relic (ticks).
- `fe_tmp` (`dummy`): Math scratchpad.
- `fe_menu` (`trigger`): Interactive menu trigger for non-OP players.
- `fe_relic_1` (`trigger`): Trigger to spawn/claim Fire Relic.
- `fe_relic_2` (`trigger`): Trigger to spawn/claim Frost Relic.

### 3. Cursed Blocks (`cursed_blocks`, 12 Objectives)
- `cb_mined_stone` (`minecraft.mined:minecraft.stone`): Mined stone counter.
- `cb_mined_deep` (`minecraft.mined:minecraft.deepslate`): Mined deepslate counter.
- `cb_mined_coal` (`minecraft.mined:minecraft.coal_ore`): Mined coal ore counter.
- `cb_mined_iron` (`minecraft.mined:minecraft.iron_ore`): Mined iron ore counter.
- `cb_mined_gold` (`minecraft.mined:minecraft.gold_ore`): Mined gold ore counter.
- `cb_mined_diamond` (`minecraft.mined:minecraft.diamond_ore`): Mined diamond ore counter.
- `cb_mined_debris` (`minecraft.mined:minecraft.ancient_debris`): Mined ancient debris counter.
- `cb_active` (`dummy`): Global toggle (1 = enabled, 0 = disabled).
- `cb_safe_mode` (`dummy`): Safe mode toggle (1 = protects player builds, 0 = unrestricted).
- `cb_chance` (`dummy`): Trigger chance percentage (default 20%).
- `cb_tmp` (`dummy`): Math scratchpad.
- `cb_menu` (`trigger`): Interactive menu trigger.
- `cb_toggle` (`trigger`): Toggle active state trigger.

### 4. Reality Gauntlet (`reality_gauntlet`, 21 Objectives)
- `rg_use` (`minecraft.used:minecraft.warped_fungus_on_a_stick`): Relic use detection.
- `rg_cd_reality` (`dummy`): Reality Gem cooldown.
- `rg_cd_time` (`dummy`): Time Gem cooldown.
- `rg_cd_space` (`dummy`): Space Gem cooldown.
- `rg_cd_power` (`dummy`): Power Gem cooldown.
- `rg_cd_mind` (`dummy`): Mind Gem cooldown.
- `rg_cd_soul` (`dummy`): Soul Gem cooldown.
- `rg_cd_gauntlet` (`dummy`): Reality Gauntlet (Snap) cooldown.
- `rg_time_active` (`dummy`): Active state of Time Freeze field.
- `rg_menu` (`trigger`): Menu trigger.
- `rg_snap` (`trigger`): Snap trigger.
- `rg_tmp` (`dummy`): Math scratchpad.
- `rg_gem_space` (`trigger`), `rg_gem_time` (`trigger`), `rg_gem_reality` (`trigger`), `rg_gem_power` (`trigger`), `rg_gem_mind` (`trigger`), `rg_gem_soul` (`trigger`), `rg_claim_gaunt` (`trigger`): Player triggers for obtaining individual items.

### 5. Mystery Roulette (`mystery_roulette`, 10 Objectives)
- `mr_timer` (`dummy`): Main countdown timer (ticks).
- `mr_interval` (`dummy`): Configurable interval duration (default: 1200 ticks / 60 seconds).
- `mr_active` (`dummy`): Global active toggle (1 = running, 0 = paused).
- `mr_tmp` (`dummy`): Math scratchpad.
- `mr_roll` (`dummy`): Rolled random value (1..100).
- `mr_sec` (`dummy`): Calculated remaining seconds for display.
- `mr_use` (`minecraft.used:minecraft.warped_fungus_on_a_stick`): Detects right-click on active relics.
- `mr_cd_orb` (`dummy`): Cooldown timer for the Orb of Thunder.
- `mr_menu` (`trigger`): Interactive GUI menu trigger.
- `mr_spin` (`trigger`): Manual spin trigger.

---

## 🎲 Cross-Project Namespace Collision Matrix

| Check Metric | Evolution Sword | Four Elements | Cursed Blocks | Reality Gauntlet | Mystery Roulette | Total Collisions |
|---|---|---|---|---|---|---|
| **Namespace** | `evo_sword` | `four_elements` | `cursed_blocks` | `reality_gauntlet` | `mystery_roulette` | **0** |
| **Scoreboard Prefix** | `es_` | `fe_` | `cb_` | `rg_` | `mr_` | **0** |
| **Function Prefix** | `evo_sword:` | `four_elements:` | `cursed_blocks:` | `reality_gauntlet:` | `mystery_roulette:` | **0** |
| **Loot Table Prefix** | `evo_sword:` | `four_elements:` | `cursed_blocks:` | `reality_gauntlet:` | `mystery_roulette:` | **0** |
| **Custom Data NBT** | `evo_sword` | `fe_*` | `cb_*` | `rg_*` | `mr_*` | **0** |

All 5 datapacks operate in total technical isolation and can be run simultaneously in the same world without cross-talk or race conditions.
