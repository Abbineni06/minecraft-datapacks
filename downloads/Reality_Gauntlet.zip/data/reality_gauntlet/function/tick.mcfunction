scoreboard players enable @a rg_menu
scoreboard players enable @a rg_get_gauntlet
scoreboard players enable @a rg_get_all_gems

execute as @a run function reality_gauntlet:trigger_handler

# Decrement cooldowns
scoreboard players remove @a[scores={rg_cd_space=1..}] rg_cd_space 1
scoreboard players remove @a[scores={rg_cd_time=1..}] rg_cd_time 1
scoreboard players remove @a[scores={rg_cd_storm=1..}] rg_cd_storm 1
scoreboard players remove @a[scores={rg_cd_life=1..}] rg_cd_life 1
scoreboard players remove @a[scores={rg_cd_gravity=1..}] rg_cd_gravity 1
scoreboard players remove @a[scores={rg_cd_power=1..}] rg_cd_power 1
scoreboard players remove @a[scores={rg_cd_ultimate=1..}] rg_cd_ultimate 1

# Check inventory gem count for players holding gauntlet
execute as @a if items entity @s weapon *[custom_data~{reality_gauntlet:true,item:"gauntlet"}] run function reality_gauntlet:player/check_gems

# Handle right clicks
execute as @a[scores={rg_use=1..}] at @s run function reality_gauntlet:player/on_use
scoreboard players set @a[scores={rg_use=1..}] rg_use 0
