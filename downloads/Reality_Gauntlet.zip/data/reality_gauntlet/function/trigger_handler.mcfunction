execute if score @s rg_menu matches 1.. run function reality_gauntlet:admin/menu
scoreboard players set @s[scores={rg_menu=1..}] rg_menu 0

execute if score @s rg_get_gauntlet matches 1.. run loot give @s loot reality_gauntlet:gauntlet
scoreboard players set @s[scores={rg_get_gauntlet=1..}] rg_get_gauntlet 0

execute if score @s rg_get_all_gems matches 1.. run function reality_gauntlet:admin/give_all_gems
scoreboard players set @s[scores={rg_get_all_gems=1..}] rg_get_all_gems 0
