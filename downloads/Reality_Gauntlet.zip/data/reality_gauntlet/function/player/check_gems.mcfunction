scoreboard players set @s rg_gem_count 0

execute if items entity @s container.* *[custom_data~{reality_gauntlet:true,gem:"space"}] run scoreboard players add @s rg_gem_count 1
execute if items entity @s container.* *[custom_data~{reality_gauntlet:true,gem:"time"}] run scoreboard players add @s rg_gem_count 1
execute if items entity @s container.* *[custom_data~{reality_gauntlet:true,gem:"storm"}] run scoreboard players add @s rg_gem_count 1
execute if items entity @s container.* *[custom_data~{reality_gauntlet:true,gem:"life"}] run scoreboard players add @s rg_gem_count 1
execute if items entity @s container.* *[custom_data~{reality_gauntlet:true,gem:"gravity"}] run scoreboard players add @s rg_gem_count 1
execute if items entity @s container.* *[custom_data~{reality_gauntlet:true,gem:"power"}] run scoreboard players add @s rg_gem_count 1

# Actionbar status
execute if score @s rg_gem_count matches ..5 run title @s actionbar ["",{"text":"Reality Gauntlet: ","color":"gold","bold":true},{"text":"[Gems: ","color":"gray"},{"score":{"name":"@s","objective":"rg_gem_count"},"color":"yellow","bold":true},{"text":"/6]","color":"gray"},{"text":" (Collect all 6 to unlock Ultimate)","color":"dark_gray"}]
execute if score @s rg_gem_count matches 6 run title @s actionbar ["",{"text":"★ THE REALITY GAUNTLET IS COMPLETE ★","color":"gold","bold":true},{"text":" [Right-Click for Cosmic Snap!]","color":"light_purple","bold":true}]
