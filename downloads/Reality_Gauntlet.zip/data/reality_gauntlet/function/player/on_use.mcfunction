execute if items entity @s weapon.mainhand *[custom_data~{reality_gauntlet:true,gem:"space"}] run function reality_gauntlet:ability/space
execute if items entity @s weapon.mainhand *[custom_data~{reality_gauntlet:true,gem:"time"}] run function reality_gauntlet:ability/time
execute if items entity @s weapon.mainhand *[custom_data~{reality_gauntlet:true,gem:"storm"}] run function reality_gauntlet:ability/storm
execute if items entity @s weapon.mainhand *[custom_data~{reality_gauntlet:true,gem:"life"}] run function reality_gauntlet:ability/life
execute if items entity @s weapon.mainhand *[custom_data~{reality_gauntlet:true,gem:"gravity"}] run function reality_gauntlet:ability/gravity
execute if items entity @s weapon.mainhand *[custom_data~{reality_gauntlet:true,gem:"power"}] run function reality_gauntlet:ability/power
execute if items entity @s weapon.mainhand *[custom_data~{reality_gauntlet:true,item:"gauntlet"}] run function reality_gauntlet:ability/ultimate
