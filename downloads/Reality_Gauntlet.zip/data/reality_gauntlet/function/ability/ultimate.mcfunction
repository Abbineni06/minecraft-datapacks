# Require all 6 gems
execute unless score @s rg_gem_count matches 6 run title @s actionbar ["",{"text":"You need all 6 Cosmic Gems to use the Gauntlet! (","color":"red"},{"score":{"name":"@s","objective":"rg_gem_count"},"color":"yellow"},{"text":"/6)","color":"red"}]
execute unless score @s rg_gem_count matches 6 run return 0

# Check cooldown
execute if score @s rg_cd_ultimate matches 1.. run title @s actionbar ["",{"text":"Gauntlet recharging (","color":"gold"},{"score":{"name":"@s","objective":"rg_cd_ultimate"},"color":"yellow"},{"text":"t)","color":"gold"}]
execute if score @s rg_cd_ultimate matches 1.. run return 0

# Apply 60s cooldown (1200 ticks)
scoreboard players set @s rg_cd_ultimate 1200

# Ultimate FX & Announcements
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.0
playsound minecraft:item.totem.use master @s ~ ~ ~ 1.0 0.8
particle minecraft:totem_of_undying ~ ~1.5 ~ 1.5 1.0 1.5 0.3 100 normal
particle minecraft:dragon_breath ~ ~1.5 ~ 2.0 1.0 2.0 0.1 80 normal

title @s title ["",{"text":"⚡ THE COSMIC SNAP ⚡","color":"gold","bold":true}]
title @s subtitle ["",{"text":"Reality bows before your command!","color":"light_purple"}]
tellraw @a ["",{"text":"🌌 [Reality Gauntlet] ","color":"gold","bold":true},{"selector":"@s","color":"aqua","bold":true},{"text":" snapped their fingers and rewrote reality!","color":"yellow"}]

# Disintegrate 50% of hostile mobs in 30 block radius
execute at @s as @e[distance=..30,type=#minecraft:skeletons,limit=5] run damage @s 100 minecraft:magic by @p
execute at @s as @e[distance=..30,type=#minecraft:zombies,limit=5] run damage @s 100 minecraft:magic by @p
execute at @s as @e[distance=..30,type=minecraft:spider,limit=5] run damage @s 100 minecraft:magic by @p
execute at @s as @e[distance=..30,type=minecraft:creeper,limit=5] run damage @s 100 minecraft:magic by @p

# Grant Godly Buffs to caster (Resistance V for 10s, Strength V for 10s)
effect give @s minecraft:resistance 10 4 true
effect give @s minecraft:strength 10 4 true
