execute if score @s rg_cd_gravity matches 1.. run title @s actionbar ["",{"text":"Gravity Gem recharging (","color":"dark_purple"},{"score":{"name":"@s","objective":"rg_cd_gravity"},"color":"yellow"},{"text":"t)","color":"dark_purple"}]
execute if score @s rg_cd_gravity matches 1.. run return 0
scoreboard players set @s rg_cd_gravity 240

playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1.0 1.4
particle minecraft:reverse_portal ~ ~1 ~ 1.5 0.5 1.5 0.2 60 normal
execute at @s as @e[distance=..10,type=#minecraft:skeletons] run effect give @s minecraft:levitation 3 3 true
execute at @s as @e[distance=..10,type=#minecraft:zombies] run effect give @s minecraft:levitation 3 3 true
execute at @s as @e[distance=..10,type=minecraft:spider] run effect give @s minecraft:levitation 3 3 true
execute at @s as @e[distance=..10,type=minecraft:creeper] run effect give @s minecraft:levitation 3 3 true
title @s actionbar ["",{"text":"🌌 GRAVITATIONAL COLLAPSE! 🌌","color":"dark_purple","bold":true}]
