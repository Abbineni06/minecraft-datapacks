execute if score @s rg_cd_life matches 1.. run title @s actionbar ["",{"text":"Life Gem recharging (","color":"gold"},{"score":{"name":"@s","objective":"rg_cd_life"},"color":"yellow"},{"text":"t)","color":"gold"}]
execute if score @s rg_cd_life matches 1.. run return 0
scoreboard players set @s rg_cd_life 300

playsound minecraft:item.totem.use master @s ~ ~ ~ 1.0 1.2
particle minecraft:heart ~ ~1.5 ~ 0.8 0.8 0.8 0.1 25 normal
effect give @s minecraft:instant_health 1 1 true
effect give @s minecraft:regeneration 6 1 true
effect give @s minecraft:saturation 4 0 true
title @s actionbar ["",{"text":"💖 VITALITY SURGE! 💖","color":"gold","bold":true}]
