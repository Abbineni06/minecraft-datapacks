execute if score @s rg_cd_space matches 1.. run title @s actionbar ["",{"text":"Space Gem recharging (","color":"blue"},{"score":{"name":"@s","objective":"rg_cd_space"},"color":"yellow"},{"text":"t)","color":"blue"}]
execute if score @s rg_cd_space matches 1.. run return 0
scoreboard players set @s rg_cd_space 100

playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1.0 1.2
particle minecraft:portal ~ ~1 ~ 0.5 0.5 0.5 0.2 40 normal
execute at @s run tp @s ^ ^ ^8
particle minecraft:portal ~ ~1 ~ 0.5 0.5 0.5 0.2 40 normal
title @s actionbar ["",{"text":"🌌 SPATIAL WARP! 🌌","color":"blue","bold":true}]
