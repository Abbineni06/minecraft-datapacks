execute if score @s rg_cd_power matches 1.. run title @s actionbar ["",{"text":"Power Gem recharging (","color":"red"},{"score":{"name":"@s","objective":"rg_cd_power"},"color":"yellow"},{"text":"t)","color":"red"}]
execute if score @s rg_cd_power matches 1.. run return 0
scoreboard players set @s rg_cd_power 300

playsound minecraft:entity.generic.explode master @s ~ ~ ~ 1.0 0.8
particle minecraft:explosion ~ ~1 ~ 1.5 0.5 1.5 0.1 20 normal
execute at @s as @e[distance=..10,type=#minecraft:skeletons] run damage @s 16 minecraft:generic by @p
execute at @s as @e[distance=..10,type=#minecraft:zombies] run damage @s 16 minecraft:generic by @p
execute at @s as @e[distance=..10,type=minecraft:spider] run damage @s 16 minecraft:generic by @p
execute at @s as @e[distance=..10,type=minecraft:creeper] run damage @s 16 minecraft:generic by @p
title @s actionbar ["",{"text":"💥 COSMIC CATACLYSM! 💥","color":"red","bold":true}]
