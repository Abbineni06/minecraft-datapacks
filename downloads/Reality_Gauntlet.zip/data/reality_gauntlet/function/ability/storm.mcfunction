execute if score @s rg_cd_storm matches 1.. run title @s actionbar ["",{"text":"Storm Gem recharging (","color":"yellow"},{"score":{"name":"@s","objective":"rg_cd_storm"},"color":"yellow"},{"text":"t)","color":"yellow"}]
execute if score @s rg_cd_storm matches 1.. run return 0
scoreboard players set @s rg_cd_storm 200

playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 1.0 1.2
particle minecraft:electric_spark ~ ~1 ~ 1.0 0.5 1.0 0.2 50 normal
execute at @s as @e[distance=1..16,type=#minecraft:skeletons,limit=3,sort=nearest] run damage @s 14 minecraft:lightning_bolt by @p
execute at @s as @e[distance=1..16,type=#minecraft:zombies,limit=3,sort=nearest] run damage @s 14 minecraft:lightning_bolt by @p
execute at @s as @e[distance=1..16,type=minecraft:spider,limit=3,sort=nearest] run damage @s 14 minecraft:lightning_bolt by @p
execute at @s as @e[distance=1..16,type=minecraft:creeper,limit=3,sort=nearest] run damage @s 14 minecraft:lightning_bolt by @p
title @s actionbar ["",{"text":"⚡ TEMPEST SMITE! ⚡","color":"yellow","bold":true}]
