execute if score @s rg_cd_time matches 1.. run title @s actionbar ["",{"text":"Time Gem recharging (","color":"green"},{"score":{"name":"@s","objective":"rg_cd_time"},"color":"yellow"},{"text":"t)","color":"green"}]
execute if score @s rg_cd_time matches 1.. run return 0
scoreboard players set @s rg_cd_time 240

playsound minecraft:block.bell.use master @s ~ ~ ~ 1.0 0.8
particle minecraft:enchant ~ ~1 ~ 1.5 0.8 1.5 0.5 80 normal
execute at @s as @e[distance=..15,type=#minecraft:skeletons] run effect give @s minecraft:slowness 6 9 true
execute at @s as @e[distance=..15,type=#minecraft:zombies] run effect give @s minecraft:slowness 6 9 true
execute at @s as @e[distance=..15,type=minecraft:spider] run effect give @s minecraft:slowness 6 9 true
execute at @s as @e[distance=..15,type=minecraft:creeper] run effect give @s minecraft:slowness 6 9 true
title @s actionbar ["",{"text":"⏳ CHRONO STASIS ACTIVATED! ⏳","color":"green","bold":true}]
