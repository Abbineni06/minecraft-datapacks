# Reality Gauntlet Initialization
scoreboard objectives add rg_use minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add rg_has_space dummy
scoreboard objectives add rg_has_time dummy
scoreboard objectives add rg_has_storm dummy
scoreboard objectives add rg_has_life dummy
scoreboard objectives add rg_has_gravity dummy
scoreboard objectives add rg_has_power dummy
scoreboard objectives add rg_gem_count dummy

scoreboard objectives add rg_cd_space dummy
scoreboard objectives add rg_cd_time dummy
scoreboard objectives add rg_cd_storm dummy
scoreboard objectives add rg_cd_life dummy
scoreboard objectives add rg_cd_gravity dummy
scoreboard objectives add rg_cd_power dummy
scoreboard objectives add rg_cd_ultimate dummy

scoreboard objectives add rg_menu trigger
scoreboard objectives add rg_get_gauntlet trigger
scoreboard objectives add rg_get_all_gems trigger

# Enable triggers
scoreboard players enable @a rg_menu
scoreboard players enable @a rg_get_gauntlet
scoreboard players enable @a rg_get_all_gems

tellraw @a ["",{"text":"✨ [Reality Gauntlet] ","color":"gold","bold":true},{"text":"Datapack active! Click ","color":"yellow"},{"text":"[Open Gauntlet Menu]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger rg_menu"},"hoverEvent":{"action":"show_text","contents":"Open Gauntlet Control Panel"}},{"text":" to claim your Gauntlet and Gems!","color":"yellow"}]
