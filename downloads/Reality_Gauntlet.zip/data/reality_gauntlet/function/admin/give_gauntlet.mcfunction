loot give @s loot reality_gauntlet:gauntlet
tellraw @s ["",{"text":"[Reality Gauntlet] ","color":"gold","bold":true},{"text":"Claimed The Reality Gauntlet!","color":"yellow"}]
