loot give @s loot reality_gauntlet:gauntlet
loot give @s loot reality_gauntlet:gem/space
loot give @s loot reality_gauntlet:gem/time
loot give @s loot reality_gauntlet:gem/storm
loot give @s loot reality_gauntlet:gem/life
loot give @s loot reality_gauntlet:gem/gravity
loot give @s loot reality_gauntlet:gem/power
tellraw @s ["",{"text":"[Reality Gauntlet] ","color":"gold","bold":true},{"text":"Granted The Reality Gauntlet and all 6 Cosmic Gems!","color":"green"}]
