# Swap hotbar.1 with hotbar.7
item replace block 0 315 0 container.0 from entity @s hotbar.1
item replace entity @s hotbar.1 from entity @s hotbar.7
item replace entity @s hotbar.7 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
