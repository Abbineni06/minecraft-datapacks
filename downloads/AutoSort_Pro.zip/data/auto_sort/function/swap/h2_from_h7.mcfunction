# Swap hotbar.2 with hotbar.7
item replace block 0 315 0 container.0 from entity @s hotbar.2
item replace entity @s hotbar.2 from entity @s hotbar.7
item replace entity @s hotbar.7 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
