# Swap armor.chest with hotbar.2
item replace block 0 315 0 container.0 from entity @s armor.chest
item replace entity @s armor.chest from entity @s hotbar.2
item replace entity @s hotbar.2 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
