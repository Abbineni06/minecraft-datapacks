# Swap hotbar.8 with inventory.3
item replace block 0 315 0 container.0 from entity @s hotbar.8
item replace entity @s hotbar.8 from entity @s inventory.3
item replace entity @s inventory.3 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
