# Swap armor.head with inventory.2
item replace block 0 315 0 container.0 from entity @s armor.head
item replace entity @s armor.head from entity @s inventory.2
item replace entity @s inventory.2 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
