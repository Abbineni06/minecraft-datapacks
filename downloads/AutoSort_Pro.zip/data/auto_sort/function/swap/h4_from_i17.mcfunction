# Swap hotbar.4 with inventory.17
item replace block 0 315 0 container.0 from entity @s hotbar.4
item replace entity @s hotbar.4 from entity @s inventory.17
item replace entity @s inventory.17 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
