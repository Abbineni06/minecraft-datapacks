# Swap hotbar.2 with inventory.14
item replace block 0 315 0 container.0 from entity @s hotbar.2
item replace entity @s hotbar.2 from entity @s inventory.14
item replace entity @s inventory.14 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
