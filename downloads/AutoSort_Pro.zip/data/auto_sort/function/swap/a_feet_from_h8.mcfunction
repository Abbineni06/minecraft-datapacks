# Swap armor.feet with hotbar.8
item replace block 0 315 0 container.0 from entity @s armor.feet
item replace entity @s armor.feet from entity @s hotbar.8
item replace entity @s hotbar.8 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
