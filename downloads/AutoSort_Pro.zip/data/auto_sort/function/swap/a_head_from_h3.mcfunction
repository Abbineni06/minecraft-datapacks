# Swap armor.head with hotbar.3
item replace block 0 315 0 container.0 from entity @s armor.head
item replace entity @s armor.head from entity @s hotbar.3
item replace entity @s hotbar.3 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
