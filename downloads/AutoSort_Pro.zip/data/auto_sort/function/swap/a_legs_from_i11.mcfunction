# Swap armor.legs with inventory.11
item replace block 0 315 0 container.0 from entity @s armor.legs
item replace entity @s armor.legs from entity @s inventory.11
item replace entity @s inventory.11 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
