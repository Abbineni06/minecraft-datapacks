# Swap hotbar.4 with hotbar.8
item replace block 0 315 0 container.0 from entity @s hotbar.4
item replace entity @s hotbar.4 from entity @s hotbar.8
item replace entity @s hotbar.8 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
