# Swap armor.legs with inventory.17
item replace block 0 315 0 container.0 from entity @s armor.legs
item replace entity @s armor.legs from entity @s inventory.17
item replace entity @s inventory.17 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
