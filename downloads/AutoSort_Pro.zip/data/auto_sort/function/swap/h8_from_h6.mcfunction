# Swap hotbar.8 with hotbar.6
item replace block 0 315 0 container.0 from entity @s hotbar.8
item replace entity @s hotbar.8 from entity @s hotbar.6
item replace entity @s hotbar.6 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
