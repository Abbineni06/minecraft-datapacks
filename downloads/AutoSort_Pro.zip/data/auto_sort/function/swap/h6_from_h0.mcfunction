# Swap hotbar.6 with hotbar.0
item replace block 0 315 0 container.0 from entity @s hotbar.6
item replace entity @s hotbar.6 from entity @s hotbar.0
item replace entity @s hotbar.0 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
