# Swap armor.head with inventory.26
item replace block 0 315 0 container.0 from entity @s armor.head
item replace entity @s armor.head from entity @s inventory.26
item replace entity @s inventory.26 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
