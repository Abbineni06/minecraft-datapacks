# Swap hotbar.0 with inventory.3
item replace block 0 315 0 container.0 from entity @s hotbar.0
item replace entity @s hotbar.0 from entity @s inventory.3
item replace entity @s inventory.3 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
