# Swap hotbar.2 with inventory.1
item replace block 0 315 0 container.0 from entity @s hotbar.2
item replace entity @s hotbar.2 from entity @s inventory.1
item replace entity @s inventory.1 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
