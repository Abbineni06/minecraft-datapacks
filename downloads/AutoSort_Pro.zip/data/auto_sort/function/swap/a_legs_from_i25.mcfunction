# Swap armor.legs with inventory.25
item replace block 0 315 0 container.0 from entity @s armor.legs
item replace entity @s armor.legs from entity @s inventory.25
item replace entity @s inventory.25 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
