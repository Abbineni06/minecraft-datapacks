# Swap armor.head with inventory.23
item replace block 0 315 0 container.0 from entity @s armor.head
item replace entity @s armor.head from entity @s inventory.23
item replace entity @s inventory.23 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
