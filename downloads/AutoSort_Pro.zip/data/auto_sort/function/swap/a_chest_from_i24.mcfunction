# Swap armor.chest with inventory.24
item replace block 0 315 0 container.0 from entity @s armor.chest
item replace entity @s armor.chest from entity @s inventory.24
item replace entity @s inventory.24 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
