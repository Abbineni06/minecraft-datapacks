# Swap hotbar.0 with inventory.8
item replace block 0 315 0 container.0 from entity @s hotbar.0
item replace entity @s hotbar.0 from entity @s inventory.8
item replace entity @s inventory.8 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
