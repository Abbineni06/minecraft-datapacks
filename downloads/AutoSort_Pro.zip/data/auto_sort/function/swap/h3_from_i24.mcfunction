# Swap hotbar.3 with inventory.24
item replace block 0 315 0 container.0 from entity @s hotbar.3
item replace entity @s hotbar.3 from entity @s inventory.24
item replace entity @s inventory.24 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
