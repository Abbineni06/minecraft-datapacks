# Swap hotbar.5 with hotbar.8
item replace block 0 315 0 container.0 from entity @s hotbar.5
item replace entity @s hotbar.5 from entity @s hotbar.8
item replace entity @s hotbar.8 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
