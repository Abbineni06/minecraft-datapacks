# Swap hotbar.3 with hotbar.4
item replace block 0 315 0 container.0 from entity @s hotbar.3
item replace entity @s hotbar.3 from entity @s hotbar.4
item replace entity @s hotbar.4 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
