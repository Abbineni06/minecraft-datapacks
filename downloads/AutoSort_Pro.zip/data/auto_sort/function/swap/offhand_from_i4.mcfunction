# Swap weapon.offhand with inventory.4
item replace block 0 315 0 container.0 from entity @s weapon.offhand
item replace entity @s weapon.offhand from entity @s inventory.4
item replace entity @s inventory.4 from block 0 315 0 container.0
item replace block 0 315 0 container.0 with air
