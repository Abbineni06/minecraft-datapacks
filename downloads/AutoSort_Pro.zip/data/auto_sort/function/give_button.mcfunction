scoreboard players set @s as_trig_btn 0

loot give @s loot auto_sort:pocket_button
playsound minecraft:item.bundle.drop_contents player @s ~ ~ ~ 1.0 1.2
tellraw @s ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Received your ","color":"yellow"},{"text":"⚡ Pocket Auto-Sort Button ⚡","color":"gold","bold":true},{"text":"! Right-click anytime to sort your inventory instantly.","color":"yellow"}]
