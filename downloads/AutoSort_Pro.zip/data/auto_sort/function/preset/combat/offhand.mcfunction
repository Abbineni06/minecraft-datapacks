# Auto-equip offhand if empty
execute unless items entity @s weapon.offhand * run function auto_sort:preset/combat/find_offhand
