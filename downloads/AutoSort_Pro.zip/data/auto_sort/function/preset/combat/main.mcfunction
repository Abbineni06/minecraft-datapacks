# Combat Ready Preset Main Routine
function auto_sort:preset/combat/slot_0
function auto_sort:preset/combat/slot_1
function auto_sort:preset/combat/slot_2
function auto_sort:preset/combat/slot_3
function auto_sort:preset/combat/slot_4
function auto_sort:preset/combat/slot_5
function auto_sort:preset/combat/slot_6
function auto_sort:preset/combat/slot_7
function auto_sort:preset/combat/slot_8
function auto_sort:preset/combat/offhand
function auto_sort:preset/combat/armor

title @s actionbar ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Sorted: ","color":"yellow"},{"text":"🗡️ Combat Ready Preset","color":"red","bold":true},{"text":" ⚡","color":"gold","bold":true}]
