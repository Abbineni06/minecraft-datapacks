# Auto-equip empty armor slots with best available armor
execute unless items entity @s armor.head * run function auto_sort:preset/combat/find_head
execute unless items entity @s armor.chest * run function auto_sort:preset/combat/find_chest
execute unless items entity @s armor.legs * run function auto_sort:preset/combat/find_legs
execute unless items entity @s armor.feet * run function auto_sort:preset/combat/find_feet
