scoreboard players set @s as_trig_p2 0
scoreboard players set @s as_preset 2
playsound minecraft:block.stone.break player @s ~ ~ ~ 1.0 1.2
tellraw @s ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Switched active preset to: ","color":"yellow"},{"text":"[⛏️ 2. Mining Expedition]","color":"aqua","bold":true},{"text":"! Type /trigger as_trig_sort to sort.","color":"gray"}]
