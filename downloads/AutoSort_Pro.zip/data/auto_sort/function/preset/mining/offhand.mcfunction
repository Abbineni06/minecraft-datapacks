execute unless items entity @s weapon.offhand * run function auto_sort:preset/mining/find_offhand
