# Mining Expedition Preset Main Routine
function auto_sort:preset/mining/slot_0
function auto_sort:preset/mining/slot_1
function auto_sort:preset/mining/slot_2
function auto_sort:preset/mining/slot_3
function auto_sort:preset/mining/slot_4
function auto_sort:preset/mining/slot_5
function auto_sort:preset/mining/slot_6
function auto_sort:preset/mining/slot_7
function auto_sort:preset/mining/slot_8
function auto_sort:preset/mining/offhand

title @s actionbar ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Sorted: ","color":"yellow"},{"text":"⛏️ Mining Expedition Preset","color":"aqua","bold":true},{"text":" ⚡","color":"gold","bold":true}]
