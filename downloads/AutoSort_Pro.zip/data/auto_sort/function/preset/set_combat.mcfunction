scoreboard players set @s as_trig_p1 0
scoreboard players set @s as_preset 1
playsound minecraft:item.armor.equip_netherite player @s ~ ~ ~ 1.0 1.2
tellraw @s ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Switched active preset to: ","color":"yellow"},{"text":"[🗡️ 1. Combat Ready]","color":"red","bold":true},{"text":"! Type /trigger as_trig_sort to sort.","color":"gray"}]
