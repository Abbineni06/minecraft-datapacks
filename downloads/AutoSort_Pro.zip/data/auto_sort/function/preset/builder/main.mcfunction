# Master Builder Preset Main Routine
function auto_sort:preset/builder/slot_0
function auto_sort:preset/builder/slot_1
function auto_sort:preset/builder/slot_2
function auto_sort:preset/builder/slot_3
function auto_sort:preset/builder/slot_4
function auto_sort:preset/builder/slot_5
function auto_sort:preset/builder/slot_6
function auto_sort:preset/builder/slot_7
function auto_sort:preset/builder/slot_8

title @s actionbar ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Sorted: ","color":"yellow"},{"text":"🪵 Master Builder Preset","color":"green","bold":true},{"text":" ⚡","color":"gold","bold":true}]
