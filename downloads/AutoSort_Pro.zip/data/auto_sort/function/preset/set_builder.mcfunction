scoreboard players set @s as_trig_p3 0
scoreboard players set @s as_preset 3
playsound minecraft:block.wood.place player @s ~ ~ ~ 1.0 1.2
tellraw @s ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Switched active preset to: ","color":"yellow"},{"text":"[🪵 3. Master Builder]","color":"green","bold":true},{"text":"! Type /trigger as_trig_sort to sort.","color":"gray"}]
