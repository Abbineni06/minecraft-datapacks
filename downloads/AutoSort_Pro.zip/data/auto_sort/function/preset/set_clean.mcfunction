scoreboard players set @s as_trig_p4 0
scoreboard players set @s as_preset 4
playsound minecraft:item.bundle.drop_contents player @s ~ ~ ~ 1.0 1.2
tellraw @s ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Switched active preset to: ","color":"yellow"},{"text":"[🧹 4. Clean & Organize]","color":"light_purple","bold":true},{"text":"! Type /trigger as_trig_sort to sort.","color":"gray"}]
