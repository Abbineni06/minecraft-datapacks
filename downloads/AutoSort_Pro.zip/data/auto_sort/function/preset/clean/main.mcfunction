# Clean & Organize Preset Main Routine
function auto_sort:preset/clean/slot_0
function auto_sort:preset/clean/slot_1
function auto_sort:preset/clean/slot_2
function auto_sort:preset/clean/slot_3
function auto_sort:preset/clean/slot_4
function auto_sort:preset/clean/slot_5
function auto_sort:preset/clean/slot_6
function auto_sort:preset/clean/slot_7
function auto_sort:preset/clean/slot_8

title @s actionbar ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Sorted: ","color":"yellow"},{"text":"🧹 Clean & Organize Preset","color":"light_purple","bold":true},{"text":" ⚡","color":"gold","bold":true}]
