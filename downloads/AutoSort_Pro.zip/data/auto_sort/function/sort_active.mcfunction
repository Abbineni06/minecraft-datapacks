# AutoSort Pro Master Dispatcher
# Ensure player has valid preset
execute unless score @s as_preset matches 1..4 run scoreboard players set @s as_preset 1

# FX on click
playsound minecraft:block.wooden_button.click_on master @s ~ ~ ~ 1.0 1.5
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1.0 1.2
particle minecraft:happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 20 normal

# Dispatch to active preset
execute if score @s as_preset matches 1 run function auto_sort:preset/combat/main
execute if score @s as_preset matches 2 run function auto_sort:preset/mining/main
execute if score @s as_preset matches 3 run function auto_sort:preset/builder/main
execute if score @s as_preset matches 4 run function auto_sort:preset/clean/main
