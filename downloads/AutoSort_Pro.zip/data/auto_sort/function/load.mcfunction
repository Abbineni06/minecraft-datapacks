# AutoSort Pro Initialization
scoreboard objectives add as_preset dummy
scoreboard objectives add as_use minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add as_cd dummy
scoreboard objectives add as_trig_sort trigger
scoreboard objectives add as_trig_menu trigger
scoreboard objectives add as_trig_p1 trigger
scoreboard objectives add as_trig_p2 trigger
scoreboard objectives add as_trig_p3 trigger
scoreboard objectives add as_trig_p4 trigger
scoreboard objectives add as_trig_btn trigger
scoreboard objectives add as_tmp dummy

# Ensure buffer barrel exists at Overworld 0 315 0
execute in minecraft:overworld run forceload add 0 0
execute in minecraft:overworld run setblock 0 315 0 minecraft:barrel
execute in minecraft:overworld run item replace block 0 315 0 container.0 with air

# Enable triggers for all players
scoreboard players enable @a as_trig_sort
scoreboard players enable @a as_trig_menu
scoreboard players enable @a as_trig_p1
scoreboard players enable @a as_trig_p2
scoreboard players enable @a as_trig_p3
scoreboard players enable @a as_trig_p4
scoreboard players enable @a as_trig_btn

# Set default preset (1 = Combat Ready)
execute as @a unless score @s as_preset matches 1..4 run scoreboard players set @s as_preset 1

tellraw @a ["",{"text":"⚡ [AutoSort Pro] ","color":"gold","bold":true},{"text":"Active! Click ","color":"yellow"},{"text":"[⚡ SORT INVENTORY]","color":"green","bold":true,"underlined":true,"clickEvent":{"action":"run_command","value":"/trigger as_trig_sort"},"hoverEvent":{"action":"show_text","contents":"Click to auto-sort your inventory now!"}},{"text":" or type ","color":"yellow"},{"text":"/trigger as_trig_menu","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger as_trig_menu"},"hoverEvent":{"action":"show_text","contents":"Open Preset Selection Menu"}},{"text":" to change presets.","color":"yellow"}]
