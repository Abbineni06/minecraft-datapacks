scoreboard players set @s as_trig_sort 0
function auto_sort:sort_active
