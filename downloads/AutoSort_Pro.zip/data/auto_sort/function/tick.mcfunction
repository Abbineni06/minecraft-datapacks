# AutoSort Pro Main Tick
# Maintain triggers
scoreboard players enable @a as_trig_sort
scoreboard players enable @a as_trig_menu
scoreboard players enable @a as_trig_p1
scoreboard players enable @a as_trig_p2
scoreboard players enable @a as_trig_p3
scoreboard players enable @a as_trig_p4
scoreboard players enable @a as_trig_btn

# Handle Triggers
execute as @a[scores={as_trig_sort=1..}] at @s run function auto_sort:trigger/sort
execute as @a[scores={as_trig_menu=1..}] at @s run function auto_sort:menu
execute as @a[scores={as_trig_p1=1..}] at @s run function auto_sort:preset/set_combat
execute as @a[scores={as_trig_p2=1..}] at @s run function auto_sort:preset/set_mining
execute as @a[scores={as_trig_p3=1..}] at @s run function auto_sort:preset/set_builder
execute as @a[scores={as_trig_p4=1..}] at @s run function auto_sort:preset/set_clean
execute as @a[scores={as_trig_btn=1..}] at @s run function auto_sort:give_button

# Handle Handheld Pocket Sorter Use
execute as @a[scores={as_use=1..}] if items entity @s weapon.mainhand *[custom_data~{auto_sort_btn:1}] at @s run function auto_sort:player/on_use
execute as @a[scores={as_use=1..}] if items entity @s weapon.offhand *[custom_data~{auto_sort_btn:1}] at @s run function auto_sort:player/on_use
scoreboard players set @a[scores={as_use=1..}] as_use 0

# Cooldown countdown
execute as @a[scores={as_cd=1..}] run scoreboard players remove @s as_cd 1
