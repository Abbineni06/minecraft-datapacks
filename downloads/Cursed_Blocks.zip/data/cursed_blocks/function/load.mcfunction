# Cursed Blocks Initialization
scoreboard objectives add cb_mined_stone minecraft.mined:minecraft.stone
scoreboard objectives add cb_mined_deep minecraft.mined:minecraft.deepslate
scoreboard objectives add cb_mined_coal minecraft.mined:minecraft.coal_ore
scoreboard objectives add cb_mined_iron minecraft.mined:minecraft.iron_ore
scoreboard objectives add cb_mined_gold minecraft.mined:minecraft.gold_ore
scoreboard objectives add cb_mined_diamond minecraft.mined:minecraft.diamond_ore
scoreboard objectives add cb_mined_debris minecraft.mined:minecraft.ancient_debris
scoreboard objectives add cb_active dummy
scoreboard objectives add cb_safe_mode dummy
scoreboard objectives add cb_chance dummy
scoreboard objectives add cb_tmp dummy
scoreboard objectives add cb_menu trigger
scoreboard objectives add cb_toggle trigger

# Defaults
execute unless score #global cb_active matches 0..1 run scoreboard players set #global cb_active 1
execute unless score #global cb_safe_mode matches 0..1 run scoreboard players set #global cb_safe_mode 1
execute unless score #global cb_chance matches 1..100 run scoreboard players set #global cb_chance 20

# Enable triggers
scoreboard players enable @a cb_menu
scoreboard players enable @a cb_toggle

tellraw @a ["",{"text":"⛏️ [Cursed Blocks] ","color":"dark_purple","bold":true},{"text":"Active! Mining selected blocks triggers unpredictable events! Type ","color":"yellow"},{"text":"/trigger cb_menu","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger cb_menu"},"hoverEvent":{"action":"show_text","contents":"Open Cursed Blocks Menu"}},{"text":" for options.","color":"yellow"}]
