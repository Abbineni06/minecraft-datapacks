title @s actionbar ["",{"text":"✨ CURSED BLESSING! ","color":"gold","bold":true},{"text":"[TREASURE DROP]","color":"yellow"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1.0 1.5
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.1 30 normal
loot spawn ~ ~1 ~ loot cursed_blocks:reward/treasure
