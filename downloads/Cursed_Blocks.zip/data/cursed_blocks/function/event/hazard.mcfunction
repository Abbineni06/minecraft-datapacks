title @s actionbar ["",{"text":"💀 CURSED HAZARD! ","color":"dark_red","bold":true},{"text":"[AFFLICTION TRIGGERED]","color":"red"}]
playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1.0 0.8
particle minecraft:smoke ~ ~1 ~ 0.6 0.6 0.6 0.1 50 normal

# Randomize hazard: 1 = Blindness, 2 = Poison Mist, 3 = Shockwave
execute store result score #sub cb_tmp run random value 1..3
execute if score #sub cb_tmp matches 1 run effect give @s minecraft:darkness 10 0 true
execute if score #sub cb_tmp matches 1 run effect give @s minecraft:blindness 6 0 true
execute if score #sub cb_tmp matches 2 run effect give @s minecraft:poison 6 1 true
execute if score #sub cb_tmp matches 3 run damage @s 6 minecraft:magic
