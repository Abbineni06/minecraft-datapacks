title @s actionbar ["",{"text":"🌀 CURSED ANOMALY! ","color":"dark_purple","bold":true},{"text":"[MYSTERY EFFECT]","color":"light_purple"}]
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1.0 1.2
particle minecraft:portal ~ ~1 ~ 0.6 0.6 0.6 0.2 40 normal

# Randomize surprise: 1 = Haste & Speed, 2 = Jump Boost & Slow Fall, 3 = Bonus XP
execute store result score #sub cb_tmp run random value 1..3
execute if score #sub cb_tmp matches 1 run effect give @s minecraft:haste 30 1 true
execute if score #sub cb_tmp matches 1 run effect give @s minecraft:speed 20 1 true
execute if score #sub cb_tmp matches 2 run effect give @s minecraft:jump_boost 15 2 true
execute if score #sub cb_tmp matches 2 run effect give @s minecraft:slow_falling 20 0 true
execute if score #sub cb_tmp matches 3 run experience add @s 150 points
