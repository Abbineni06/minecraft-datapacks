title @s actionbar ["",{"text":"☠️ ANCIENT CURSED GUARDIAN RISES! ☠️","color":"dark_red","bold":true}]
tellraw @a ["",{"text":"⚠️ [Cursed Blocks] ","color":"dark_red","bold":true},{"selector":"@s","color":"aqua"},{"text":" disturbed an ","color":"yellow"},{"text":"Ancient Crypt Guardian","color":"dark_red","bold":true},{"text":"!","color":"yellow"}]
playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.8 1.2
particle minecraft:dragon_breath ~ ~1 ~ 1.0 0.8 1.0 0.1 60 normal

# Summon Guardian Wither Skeleton with custom helmet and enchanted sword
summon wither_skeleton ~ ~ ~ {CustomName:'[{"text":"Crypt Guardian","color":"dark_red","bold":true}]',CustomNameVisible:1b,HandItems:[{id:"minecraft:netherite_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":3,"minecraft:fire_aspect":1}}},{id:"minecraft:shield",count:1}],ArmorItems:[{},{},{},{id:"minecraft:netherite_helmet",count:1}]}
