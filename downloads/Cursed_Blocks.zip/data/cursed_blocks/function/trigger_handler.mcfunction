execute if score @s cb_menu matches 1.. run function cursed_blocks:admin/menu
scoreboard players set @s[scores={cb_menu=1..}] cb_menu 0

execute if score @s cb_toggle matches 1.. run function cursed_blocks:admin/toggle_active
scoreboard players set @s[scores={cb_toggle=1..}] cb_toggle 0
