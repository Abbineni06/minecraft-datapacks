# Roll event category: 1..40 = Reward, 41..70 = Hazard, 71..90 = Surprise, 91..100 = Boss
execute store result score #event cb_tmp run random value 1..100

execute if score #event cb_tmp matches 1..40 run function cursed_blocks:event/reward
execute if score #event cb_tmp matches 41..70 run function cursed_blocks:event/hazard
execute if score #event cb_tmp matches 71..90 run function cursed_blocks:event/surprise
execute if score #event cb_tmp matches 91..100 run function cursed_blocks:event/boss
