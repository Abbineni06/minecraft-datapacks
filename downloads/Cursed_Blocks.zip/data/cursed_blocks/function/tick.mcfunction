scoreboard players enable @a cb_menu
scoreboard players enable @a cb_toggle

execute as @a run function cursed_blocks:trigger_handler

# Detect mined blocks if active
execute if score #global cb_active matches 1 as @a[scores={cb_mined_stone=1..}] at @s run function cursed_blocks:check_trigger
execute if score #global cb_active matches 1 as @a[scores={cb_mined_deep=1..}] at @s run function cursed_blocks:check_trigger
execute if score #global cb_active matches 1 as @a[scores={cb_mined_coal=1..}] at @s run function cursed_blocks:check_trigger
execute if score #global cb_active matches 1 as @a[scores={cb_mined_iron=1..}] at @s run function cursed_blocks:check_trigger
execute if score #global cb_active matches 1 as @a[scores={cb_mined_gold=1..}] at @s run function cursed_blocks:check_trigger
execute if score #global cb_active matches 1 as @a[scores={cb_mined_diamond=1..}] at @s run function cursed_blocks:check_trigger
execute if score #global cb_active matches 1 as @a[scores={cb_mined_debris=1..}] at @s run function cursed_blocks:check_trigger

# Reset mined scores
scoreboard players set @a[scores={cb_mined_stone=1..}] cb_mined_stone 0
scoreboard players set @a[scores={cb_mined_deep=1..}] cb_mined_deep 0
scoreboard players set @a[scores={cb_mined_coal=1..}] cb_mined_coal 0
scoreboard players set @a[scores={cb_mined_iron=1..}] cb_mined_iron 0
scoreboard players set @a[scores={cb_mined_gold=1..}] cb_mined_gold 0
scoreboard players set @a[scores={cb_mined_diamond=1..}] cb_mined_diamond 0
scoreboard players set @a[scores={cb_mined_debris=1..}] cb_mined_debris 0
