# Roll against configured trigger probability (default 20%)
execute store result score #roll cb_tmp run random value 1..100
execute if score #roll cb_tmp <= #global cb_chance run function cursed_blocks:dispatch_event
