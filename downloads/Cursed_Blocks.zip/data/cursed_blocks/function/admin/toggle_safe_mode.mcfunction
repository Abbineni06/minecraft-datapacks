execute if score #global cb_safe_mode matches 1 run scoreboard players set #global cb_safe_mode 0
execute unless score #global cb_safe_mode matches 0 run scoreboard players set #global cb_safe_mode 1
tellraw @s ["",{"text":"[Cursed Blocks] ","color":"dark_purple","bold":true},{"text":"Safe mode set to ","color":"yellow"},{"score":{"name":"#global","objective":"cb_safe_mode"},"color":"green"}]
