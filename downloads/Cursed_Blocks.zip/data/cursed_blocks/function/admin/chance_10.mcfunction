scoreboard players set #global cb_chance 10
tellraw @s ["",{"text":"[Cursed Blocks] ","color":"dark_purple","bold":true},{"text":"Trigger chance set to 10%.","color":"yellow"}]
