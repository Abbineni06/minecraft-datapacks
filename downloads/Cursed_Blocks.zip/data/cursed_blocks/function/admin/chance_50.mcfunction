scoreboard players set #global cb_chance 50
tellraw @s ["",{"text":"[Cursed Blocks] ","color":"dark_purple","bold":true},{"text":"Trigger chance set to 50%.","color":"yellow"}]
