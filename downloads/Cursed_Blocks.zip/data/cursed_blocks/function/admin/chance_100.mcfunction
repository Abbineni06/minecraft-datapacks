scoreboard players set #global cb_chance 100
tellraw @s ["",{"text":"[Cursed Blocks] ","color":"dark_purple","bold":true},{"text":"Trigger chance set to 100% (Every eligible block!).","color":"red"}]
