execute if score #global cb_active matches 1 run scoreboard players set #global cb_active 0
execute unless score #global cb_active matches 0 run scoreboard players set #global cb_active 1
tellraw @s ["",{"text":"[Cursed Blocks] ","color":"dark_purple","bold":true},{"text":"Active status set to ","color":"yellow"},{"score":{"name":"#global","objective":"cb_active"},"color":"aqua"}]
