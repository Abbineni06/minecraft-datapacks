scoreboard players set #global cb_chance 20
tellraw @s ["",{"text":"[Cursed Blocks] ","color":"dark_purple","bold":true},{"text":"Trigger chance set to 20%.","color":"yellow"}]
