execute if score @s evo_give matches 1.. run function evo_sword:player/give_sword
scoreboard players set @s[scores={evo_give=1..}] evo_give 0

execute if score @s evo_menu matches 1.. run function evo_sword:admin/menu
scoreboard players set @s[scores={evo_menu=1..}] evo_menu 0
