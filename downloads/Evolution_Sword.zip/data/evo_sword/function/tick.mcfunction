# Ensure triggers remain active
scoreboard players enable @a evo_give
scoreboard players enable @a evo_menu

# Handle player triggers
execute as @a run function evo_sword:trigger_handler

# Detect kills while holding Evolution Sword
execute as @a[scores={evo_mob_kills=1..}] if items entity @s weapon.mainhand *[custom_data~{evo_sword:true}] at @s run function evo_sword:player/on_kill

# Reset kill counter for all players
scoreboard players set @a[scores={evo_mob_kills=1..}] evo_mob_kills 0

# Display progress on action bar when holding Evolution Sword
execute as @a if items entity @s weapon.mainhand *[custom_data~{evo_sword:true}] run function evo_sword:player/display_actionbar
