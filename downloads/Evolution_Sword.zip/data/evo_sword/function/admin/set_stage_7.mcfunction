scoreboard players set @s evo_stage 7
scoreboard players set @s evo_progress 0
scoreboard players set @s evo_needed 40
clear @s *[custom_data~{evo_sword:true}]
loot give @s loot evo_sword:stage_7
tellraw @s ["", {"text":"[Evolution Sword] ","color":"gold","bold":true}, {"text":"Stage set to 7.","color":"green"}]
