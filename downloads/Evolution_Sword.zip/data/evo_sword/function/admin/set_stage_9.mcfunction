scoreboard players set @s evo_stage 9
scoreboard players set @s evo_progress 0
scoreboard players set @s evo_needed 75
clear @s *[custom_data~{evo_sword:true}]
loot give @s loot evo_sword:stage_9
tellraw @s ["", {"text":"[Evolution Sword] ","color":"gold","bold":true}, {"text":"Stage set to 9.","color":"green"}]
