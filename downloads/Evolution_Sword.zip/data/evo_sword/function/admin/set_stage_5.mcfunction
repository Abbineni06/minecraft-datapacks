scoreboard players set @s evo_stage 5
scoreboard players set @s evo_progress 0
scoreboard players set @s evo_needed 25
clear @s *[custom_data~{evo_sword:true}]
loot give @s loot evo_sword:stage_5
tellraw @s ["", {"text":"[Evolution Sword] ","color":"gold","bold":true}, {"text":"Stage set to 5.","color":"green"}]
