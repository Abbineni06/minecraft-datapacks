scoreboard players set @s evo_stage 3
scoreboard players set @s evo_progress 0
scoreboard players set @s evo_needed 15
clear @s *[custom_data~{evo_sword:true}]
loot give @s loot evo_sword:stage_3
tellraw @s ["", {"text":"[Evolution Sword] ","color":"gold","bold":true}, {"text":"Stage set to 3.","color":"green"}]
