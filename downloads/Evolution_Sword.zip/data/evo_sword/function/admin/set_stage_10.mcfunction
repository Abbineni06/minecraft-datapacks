scoreboard players set @s evo_stage 10
scoreboard players set @s evo_progress 0
scoreboard players set @s evo_needed 999999
clear @s *[custom_data~{evo_sword:true}]
loot give @s loot evo_sword:stage_10
tellraw @s ["", {"text":"[Evolution Sword] ","color":"gold","bold":true}, {"text":"Stage set to 10.","color":"green"}]
