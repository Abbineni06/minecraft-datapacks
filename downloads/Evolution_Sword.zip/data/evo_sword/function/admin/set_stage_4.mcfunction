scoreboard players set @s evo_stage 4
scoreboard players set @s evo_progress 0
scoreboard players set @s evo_needed 20
clear @s *[custom_data~{evo_sword:true}]
loot give @s loot evo_sword:stage_4
tellraw @s ["", {"text":"[Evolution Sword] ","color":"gold","bold":true}, {"text":"Stage set to 4.","color":"green"}]
