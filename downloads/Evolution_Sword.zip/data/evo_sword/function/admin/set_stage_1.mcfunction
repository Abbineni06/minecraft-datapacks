scoreboard players set @s evo_stage 1
scoreboard players set @s evo_progress 0
scoreboard players set @s evo_needed 5
clear @s *[custom_data~{evo_sword:true}]
loot give @s loot evo_sword:stage_1
tellraw @s ["", {"text":"[Evolution Sword] ","color":"gold","bold":true}, {"text":"Stage set to 1.","color":"green"}]
