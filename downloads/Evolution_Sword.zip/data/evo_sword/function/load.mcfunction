# Evolution Sword System Initialization
scoreboard objectives add evo_mob_kills minecraft.custom:minecraft.mob_kills
scoreboard objectives add evo_stage dummy
scoreboard objectives add evo_progress dummy
scoreboard objectives add evo_needed dummy
scoreboard objectives add evo_death_mode dummy
scoreboard objectives add evo_total_kills dummy
scoreboard objectives add evo_tmp dummy
scoreboard objectives add evo_give trigger
scoreboard objectives add evo_menu trigger

# Default configs
execute unless score #global evo_death_mode matches 0..1 run scoreboard players set #global evo_death_mode 0

# Enable triggers for players
scoreboard players enable @a evo_give
scoreboard players enable @a evo_menu

tellraw @a ["",{"text":"⚔️ [Evolution Sword] ","color":"gold","bold":true},{"text":"Datapack active! Type ","color":"yellow"},{"text":"/trigger evo_give","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/trigger evo_give"},"hoverEvent":{"action":"show_text","contents":"Click to claim your starter Awakening Blade!"}},{"text":" to claim your sword!","color":"yellow"}]
