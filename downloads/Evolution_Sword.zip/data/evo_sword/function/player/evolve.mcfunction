# Advance stage
scoreboard players add @s evo_stage 1
scoreboard players set @s evo_progress 0

# Update next stage target
execute if score @s evo_stage matches 2 run scoreboard players set @s evo_needed 10
execute if score @s evo_stage matches 3 run scoreboard players set @s evo_needed 15
execute if score @s evo_stage matches 4 run scoreboard players set @s evo_needed 20
execute if score @s evo_stage matches 5 run scoreboard players set @s evo_needed 25
execute if score @s evo_stage matches 6 run scoreboard players set @s evo_needed 30
execute if score @s evo_stage matches 7 run scoreboard players set @s evo_needed 40
execute if score @s evo_stage matches 8 run scoreboard players set @s evo_needed 50
execute if score @s evo_stage matches 9 run scoreboard players set @s evo_needed 75
execute if score @s evo_stage matches 10 run scoreboard players set @s evo_needed 999999

# Visual & Sound FX
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1.0 1.2
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1.0 1.0
particle minecraft:totem_of_undying ~ ~1.2 ~ 0.5 0.5 0.5 0.2 40 normal
particle minecraft:enchant ~ ~1.2 ~ 0.6 0.6 0.6 0.5 50 normal

# Replace sword in mainhand
clear @s *[custom_data~{evo_sword:true}]
execute if score @s evo_stage matches 2 run loot give @s loot evo_sword:stage_2
execute if score @s evo_stage matches 3 run loot give @s loot evo_sword:stage_3
execute if score @s evo_stage matches 4 run loot give @s loot evo_sword:stage_4
execute if score @s evo_stage matches 5 run loot give @s loot evo_sword:stage_5
execute if score @s evo_stage matches 6 run loot give @s loot evo_sword:stage_6
execute if score @s evo_stage matches 7 run loot give @s loot evo_sword:stage_7
execute if score @s evo_stage matches 8 run loot give @s loot evo_sword:stage_8
execute if score @s evo_stage matches 9 run loot give @s loot evo_sword:stage_9
execute if score @s evo_stage matches 10 run loot give @s loot evo_sword:stage_10

title @s title ["",{"text":"⚔️ SWORD EVOLVED! ⚔️","color":"gold","bold":true}]
title @s subtitle ["",{"text":"Reached Stage ","color":"yellow"},{"score":{"name":"@s","objective":"evo_stage"},"color":"aqua","bold":true}]
tellraw @a ["",{"text":"⚡ [Evolution Sword] ","color":"gold","bold":true},{"selector":"@s","color":"aqua","bold":true},{"text":" has evolved their sword to ","color":"yellow"},{"text":"Stage ","color":"gold"},{"score":{"name":"@s","objective":"evo_stage"},"color":"gold","bold":true},{"text":"!","color":"yellow"}]
