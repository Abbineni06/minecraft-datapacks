# Initialize stage if 0
execute unless score @s evo_stage matches 1..10 run scoreboard players set @s evo_stage 1
execute unless score @s evo_progress matches 0.. run scoreboard players set @s evo_progress 0
execute if score @s evo_stage matches 1 run scoreboard players set @s evo_needed 5

# Clear any duplicate evolution sword in inventory to prevent exploit
clear @s *[custom_data~{evo_sword:true}]

# Give sword corresponding to current unlocked stage
execute if score @s evo_stage matches 1 run loot give @s loot evo_sword:stage_1
execute if score @s evo_stage matches 2 run loot give @s loot evo_sword:stage_2
execute if score @s evo_stage matches 3 run loot give @s loot evo_sword:stage_3
execute if score @s evo_stage matches 4 run loot give @s loot evo_sword:stage_4
execute if score @s evo_stage matches 5 run loot give @s loot evo_sword:stage_5
execute if score @s evo_stage matches 6 run loot give @s loot evo_sword:stage_6
execute if score @s evo_stage matches 7 run loot give @s loot evo_sword:stage_7
execute if score @s evo_stage matches 8 run loot give @s loot evo_sword:stage_8
execute if score @s evo_stage matches 9 run loot give @s loot evo_sword:stage_9
execute if score @s evo_stage matches 10 run loot give @s loot evo_sword:stage_10

tellraw @s ["",{"text":"[Evolution Sword] ","color":"gold","bold":true},{"text":"Equipped your Evolution Sword at Stage ","color":"yellow"},{"score":{"name":"@s","objective":"evo_stage"},"color":"aqua","bold":true},{"text":"!","color":"yellow"}]
