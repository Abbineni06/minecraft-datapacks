# Prevent progression past stage 10
execute if score @s evo_stage matches 10 run return 0

# Increment progress and total stats
scoreboard players add @s evo_progress 1
scoreboard players add @s evo_total_kills 1

# Check if threshold reached
execute if score @s evo_progress >= @s evo_needed run function evo_sword:player/evolve
