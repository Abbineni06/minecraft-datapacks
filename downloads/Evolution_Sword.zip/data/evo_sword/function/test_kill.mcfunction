scoreboard players add @s evo_mob_kills 1
tellraw @s ["",{"text":"[Evolution Sword] ","color":"gold","bold":true},{"text":"Simulated 1 mob kill!","color":"green"}]
